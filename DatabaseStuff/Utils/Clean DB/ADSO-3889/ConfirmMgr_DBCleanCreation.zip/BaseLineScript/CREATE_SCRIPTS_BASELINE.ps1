<#

.NAME
	CREATE_SCRIPTS_BASELINE
.SYNOPSIS
	SCRIPT DEVELOPED TO GET ALL DATABASE OBJECTS SCRIPT FROM SQL SERVER

.DESCRIPTION
	This script generates a SQL Server objects scripts per database object including Stored Procedures,Tables,Views, 
	User Defined Functions and User Defined Table Types. Useful for versionining a databsae in a CVS.

.PARAMETERS 
	$dbusername   :  DatabaseUser with credentials to logon as sysadmin
	$dbuspassw    :  Password of Database User
	$srvinstance  :  SQL Server Instance to work
	$db_name      :  SQL Server Database Name to Script
	$schname      :  Database Schema Name
	$outdirectory :  Path directory where you want to save the SQL Scripts generated from the Database
	

.INPUTS
	
.OUTPUTS
	SchemaName.TableName.sql
	Log Results error.log
	Log Error if is necessary


.EXAMPLE
 Ps c:\> .\CREATE_SCRIPTS_BASELINE.ps1

.NOTES
	Author        :	Javier Montero  - 11/16/2015
    Version       :	1.0	
	Compatibility :	PS 2.0 or Higher
	SQL Ver       :	SQL Server 2008R2 or Higher
	TO GET HELP OR ANY NOTE HERE TYPE GET-HELP .\CreateDataBase.ps1
	
#>

param(
	[Parameter(Position=0, Mandatory=$true)]
	[string]$srvinstance,
	[Parameter(Position=1, Mandatory=$true)]
	[string]$db_name,
	[Parameter(Position=3, Mandatory=$true)]
	[string]$outdirectory,
	[Parameter(Position=2, Mandatory=$true)]
	[string]$schname,
	[Parameter(Position=4, Mandatory=$true)]
	[string]$dbusername,
	[Parameter(Position=5, Mandatory=$true)]
	[string]$dbuspassw
)

$srvinstance = Read-Host ''

$server 			= $srvinstance       #"CNF02INFDBS01\SQLSVR11"
$database 			= $db_name           #"cnf_mgr_jm"
$output_path 		= $outdirectory      #"C:\temp\cnf_mgr_jm\Schema"
$schema 		    = $schname           #"ConfirmMgr"
$username           = $dbusername
$passw              = $dbuspassw

#Setting output folder variables
$table_path 		= "$output_path\Tables\"
$storedProcs_path 	= "$output_path\StoredProcedure\"
$views_path 		= "$output_path\Views\"
$udfs_path 			= "$output_path\UserDefinedFunction\"
$textCatalog_path 	= "$output_path\FullTextCatalog\"
$udtts_path 		= "$output_path\UserDefinedTableTypes\"
$triggers_path      = "$output_path\Triggers\"
$dfc_path           = "$output_path\DefaultConstraint\"
$sequence_path      = "$output_path\Sequences\"
$indexes_path       = "$output_path\Indexes\"
$foreign_path       = "$output_path\ForeignKeys\"
$chkconstraint_path = "$output_path\CheckConstraints\"
$primarykey_path    = "$output_path\PrimaryKeys\"
$sbqueues           = "$output_path\QUEUES\"


<#It is used to load the SQL Server Library's is like to Use Import-Module SQLPS -DisableNameChecking 
The difference is with this library we can work under SQL Server 2008 or SQL 2012 without problem 
because SQLPS only is present whe the server or computer have present SQL Server DataTools
#>
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null #<-- Powershell V 1.0
#Add-Type -AssemblyName "Microsoft.SqlServer.SMO"  #<-- PowerShell V 2.0 or higher

# Creating SMO objects
$srv 		= New-Object "Microsoft.SqlServer.Management.SMO.Server" $server
$db 		= New-Object ("Microsoft.SqlServer.Management.SMO.Database")
$tbl 		= New-Object ("Microsoft.SqlServer.Management.SMO.Table")
$scripter 	= New-Object ("Microsoft.SqlServer.Management.SMO.Scripter") ($server)

#Login credentials
$srv.ConnectionContext.LoginSecure = $false
#$credential = Get-Credential
$SqlUPwd = ConvertTo-SecureString $passw -AsPlainText -Force #Converting Password text to Secury credentials
$srv.ConnectionContext.set_Login($username)
$srv.ConnectionContext.set_SecurePassword($SqlUPwd)

#Setting Database variable
$db = $srv.Databases[$database]

# Getting the database and tables objects
$tbl		 	= $db.tables | Where-object { $_.schema -eq $schema  -and -not $_.IsSystemObject } 
$storedProcs	= $db.StoredProcedures | Where-object { $_.schema -eq $schema -and -not $_.IsSystemObject } 
$views 		 	= $db.Views | Where-object { $_.schema -eq $schema } 
$udfs		 	= $db.UserDefinedFunctions | Where-object { $_.schema -eq $schema -and -not $_.IsSystemObject } 
$catlog		 	= $db.FullTextCatalogs
$udtts		 	= $db.UserDefinedTableTypes | Where-object { $_.schema -eq $schema -and -not $__.IsSystemObject }
$dfc            = $db.DefaultConstraint | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject } 
$trg            = $tbl.Triggers | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
$seq            = $db.Sequences | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
$sbq            = $db.Broker.ServiceQueue | Where-Object {$_.schema -eq $schema -and -not $_.IsSystemObject }
	
<# Set scripter options to make ensure only schema objects 
are scripted and excluding Data
#>
$scripter.Options.ScriptSchema 	= $true;
$scripter.Options.ScriptData 	= $false;


#Exclude GOs after every line
$scripter.Options.NoCommandTerminator 	= $false;
$scripter.Options.ToFileOnly 			= $true
$scripter.Options.AllowSystemObjects 	= $false
$scripter.Options.Permissions 			= $true
$scripter.Options.DriAllConstraints 	= $false
$scripter.Options.DriChecks             = $false
$scripter.Options.SchemaQualify 		= $true
$scripter.Options.AnsiFile 				= $true

$scripter.Options.SchemaQualifyForeignKeysReferences = $true

$scripter.Options.Indexes 				= $false
$scripter.Options.DriIndexes 			= $false
$scripter.Options.DriUniqueKeys         = $false
$scripter.Options.DriClustered 			= $false
$scripter.Options.DriNonClustered 		= $false
$scripter.Options.NonClusteredIndexes 	= $false
$scripter.Options.ClusteredIndexes 		= $false
$scripter.Options.FullTextIndexes 		= $false
$scripter.Options.EnforceScriptingOptions 	= $true

function CopyObjectsToFiles($objects, $outDir) {
	#Function to script Database Objects like Stored Procedure, Tables, Views and Others.
	# Receive 2 parameters object requested and out put directory
	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	
	foreach ($o in $objects) { 
	
		if ($o -ne $null) {
			
			$schemaPrefix = ""
			
			if ($o.Schema -ne $null -and $o.Schema -ne "") {
				$schemaPrefix = $o.Schema + "."
			}
		
			$scripter.Options.FileName = $outDir + $schemaPrefix + $o.Name + ".sql"
			Write-Host "Writing " $scripter.Options.FileName
			$scripter.EnumScript($o)
		}
	}
}

function TRGObjectsToFiles($outDir) {
	#Function to script the Triggers Present in the Tables.
	# Receive 1 parameters out put directory
	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	
	$tables = $tbl
	$tables = $db.Tables | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
	foreach ($o in $tables) { 
	
		if ($o -ne $null) {
			$trgs = $o.Triggers
			if($trgs -ne $null)
			{
				foreach($tr in $trgs)
				{
					
					if($tr -ne $null)
					{
						$schemaPrefix = ""
						$schemaPrefix = $schema + "."
						$scripter.Options.FileName = $outDir + $schemaPrefix + $tr.Name + ".sql"
						Write-Host "Writing " $scripter.Options.FileName
						$scripter.EnumScript($tr)
					}
					
				}
			}		
			
		}
	}
}

function IDXObjectsToFiles($outDir) {
	#Function to script Indexes Objects Presents in the Tables
	# Receive 1 parameters out put directory
	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	$scripter.Options.DriPrimaryKey        = $false
	#$scripter.Options.DriClusteredIndexes  = $false
	$scripter.Options.DriClustered         = $false
	$tables = $tbl
	$tables = $db.Tables | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
	foreach ($o in $tables) { 
	
		if ($o -ne $null) {
			$trgs = $o.Indexes
			if($trgs -ne $null)
			{
				foreach($tr in $trgs)
				{
					
					if($tr -ne $null)
					{
						if($tr.IndexKeyType -ne "DriPrimaryKey")
						{
							$schemaPrefix = ""
							$schemaPrefix = $schema + "."
							$scripter.Options.FileName = $outDir + $schemaPrefix + $tr.Name + ".sql"
							Write-Host "Writing " $scripter.Options.FileName
							$scripter.EnumScript($tr)
						}
					}
					
				}
			}		
			
		}
	}
}

function PKObjectsToFiles($outDir) {
	#Function to script Primary Objects Presents in the Tables
	# Receive 1 parameters out put directory

	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	$scripter.Options.DriPrimaryKey        = $false
	$scripter.Options.DriClustered         = $false
	$tables = $tbl
	$tables = $db.Tables | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
	foreach ($o in $tables) { 
	
		if ($o -ne $null) {
			$trgs = $o.Indexes
			if($trgs -ne $null)
			{
				foreach($tr in $trgs)
				{
					
					if($tr -ne $null)
					{
						if($tr.IndexKeyType -eq "DriPrimaryKey")
						{
							$schemaPrefix = ""
							$schemaPrefix = $schema + "."
							$scripter.Options.FileName = $outDir + $schemaPrefix + $tr.Name + ".sql"
							Write-Host "Writing " $scripter.Options.FileName
							$scripter.EnumScript($tr)
						}
					}
					
				}
			}		
			
		}
	}
}
function FKObjectsToFiles($outDir) {
	#Function to script Foreign Keys Presents the Tables
	# Receive 1 parameters out put directory

	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	
	$tables = $tbl
	$tables = $db.Tables | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
	foreach ($o in $tables) { 
	
		if ($o -ne $null) {
			$trgs = $o.ForeignKeys
			if($trgs -ne $null)
			{
				foreach($tr in $trgs)
				{
					
					if($tr -ne $null)
					{
						$schemaPrefix = ""
						$schemaPrefix = $schema + "."
						$scripter.Options.FileName = $outDir + $schemaPrefix + $tr.Name + ".sql"
						Write-Host "Writing " $scripter.Options.FileName
						$scripter.EnumScript($tr)
					}
					
				}
			}		
			
		}
	}
}
function CHKCObjectsToFiles($outDir) {
	#Function to script Check Constraint Present in the Tables
	# Receive 1 parameters out put directory

	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}	
	$tables = $tbl
	$tables = $db.Tables | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject }
	foreach ($o in $tables) { 
	
		if ($o -ne $null) {
			$trgs = $o.Checks
			if($trgs -ne $null)
			{
				foreach($tr in $trgs)
				{
					
					if($tr -ne $null)
					{
						$schemaPrefix = ""
						$schemaPrefix = $schema + "."
						$scripter.Options.FileName = $outDir + $schemaPrefix + $tr.Name + ".sql"
						Write-Host "Writing " $scripter.Options.FileName
						$scripter.EnumScript($tr)
					}
					
				}
			}		
			
		}
	}
}
function DFCObjectsToFiles($outDir) {
	#Function to script Default Constraint Present in the Tables
	# Receive 1 parameters out put directory

	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	
	$tables = $tbl #Here I did a heritage from the Table object declared above
	$tables = $db.Tables | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject } #Here I'm retrieving all Tables Objects
	foreach ($tblo in $tables) { 
		#Here I'm doing a loop table by table to get the columns with default constraints
		foreach($column in $tblo.Columns){
			#It get the columns present in the table
			if($column -ne $null){
				$dfc_column = $column.DefaultConstraint.Name # Here we are getting the Default Constraint name for build the script file name
				if($dfc_column -ne $null){
					$scripter.Options.FileName = $outDir + $dfc_column + ".sql"
					Write-Host "Writing " $scripter.Options.FileName
					$scripter.EnumScript($column.DefaultConstraint)
				}
				
			}
		}
		
	}
}

function SBQueuesObjectsToFiles($outDir) {
	#Function to script Default Constraint Present in the Tables
	# Receive 1 parameters out put directory

	if (-not (Test-Path $outDir)) {
		[System.IO.Directory]::CreateDirectory($outDir)
	}
	
	$broker = $sbq #Here I did a heritage from the Table object declared above
	$broker = $db.Broker.ServiceQueue | Where-Object {$_.schema -eq $schema -and -not $__.IsSystemObject } #Here I'm retrieving all Tables Objects
	Write-Host "Queue Name "$broker
	<#foreach ($queues in $broker) { 
		#Here I'm doing a loop table by table to get the columns with default constraints
		foreach($queque in $queues.Queue){
			#It get the columns present in the table
			if($queque -ne $null){
				$dfc_column = $column.DefaultConstraint.Name # Here we are getting the Default Constraint name for build the script file name
				if($dfc_column -ne $null){
					$scripter.Options.FileName = $outDir + $dfc_column + ".sql"
					Write-Host "Writing " $scripter.Options.FileName
					$scripter.EnumScript($column.DefaultConstraint)
				}
				
			}
		}
		
	}#>
}



# Main Program 
CopyObjectsToFiles      $tbl $table_path
CopyObjectsToFiles      $storedProcs $storedProcs_path
CopyObjectsToFiles      $views $views_path
CopyObjectsToFiles      $catlog $textCatalog_path
CopyObjectsToFiles      $udtts $udtts_path
CopyObjectsToFiles      $udfs $udfs_path
CopyObjectsToFiles      $seq $sequence_path
TRGObjectsToFiles       $triggers_path
IDXObjectsToFiles       $indexes_path
FKObjectsToFiles        $foreign_path
CHKCObjectsToFiles      $chkconstraint_path
DFCObjectsToFiles       $dfc_path
PKObjectsToFiles        $primarykey_path
SBQueuesObjectsToFiles  $sbqueues
Write-Host "Finished at" (Get-Date)
Write-Host "PS is the Best!!!!"