
/*creating role*/
create role stanford_developers
GO
PRINT 'STANFORD_DEVELOPER ROLES CREATED!!!!!!'
GO
/*granted ri	ghts to role*/
grant execute  to stanford_developers
GO
grant select to stanford_developers
GO
grant delete to stanford_developers
GO
grant insert to stanford_developers
GO
grant update to stanford_developers
GO
ALTER AUTHORIZATION ON SCHEMA::[db_datawriter] TO [stanford_developers]
GO
ALTER AUTHORIZATION ON SCHEMA::[db_datareader] TO [stanford_developers]
GO
GRANT EXECUTE ON SCHEMA::[ConfirmMgr] TO [stanford_developers]
GO
GRANT SELECT ON SCHEMA::[ConfirmMgr] TO [stanford_developers]
GO


/*adding developers to Role stanford_developers*/
/*alter role stanford_developers add member ifrankel
alter role stanford_developers add member jvega
Alter Role stanford_developers Add Member "ASH\cnfsvcprd"*/

/*GRANTS ON SCHEMAS*/
GRANT UPDATE ON SCHEMA::ConfirmMgr TO stanford_developers
GO
GRANT DELETE ON SCHEMA::ConfirmMgr TO stanford_developers
GO
GRANT ALTER ON SCHEMA::ConfirmMgr TO stanford_developers
GO
GRANT INSERT ON SCHEMA::ConfirmMgr TO stanford_developers
GO
GRANT UPDATE ON SCHEMA::AFFINF TO stanford_developers
GO
GRANT DELETE ON SCHEMA::AFFINF TO stanford_developers
GO
GRANT ALTER ON SCHEMA::AFFINF TO stanford_developers
GO
GRANT INSERT ON SCHEMA::AFFINF TO stanford_developers
GO
GRANT EXECUTE ON SCHEMA::AFFINF TO stanford_developers
GO
GRANT SELECT ON SCHEMA::AFFINF TO stanford_developers
GO
GRANT UPDATE ON SCHEMA::AFFMSG TO stanford_developers
GO
GRANT DELETE ON SCHEMA::AFFMSG TO stanford_developers
GO
GRANT ALTER ON SCHEMA::AFFMSG TO stanford_developers
GO
GRANT INSERT ON SCHEMA::AFFMSG TO stanford_developers
GO
GRANT EXECUTE ON SCHEMA::AFFMSG TO stanford_developers
GO
GRANT SELECT ON SCHEMA::AFFMSG TO stanford_developers
GO
GRANT SELECT, INSERT, DELETE, UPDATE ON OBJECT::ConfirmMgr.INBOUND_DOCS TO stanford_developers
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'cm_admin')
ALTER ROLE stanford_developers ADD MEMBER cm_admin
GO
IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'cnfmgrsvc')
ALTER ROLE stanford_developers ADD MEMBER cnfmgrsvc
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'kbarkman')
ALTER ROLE stanford_developers ADD MEMBER kbarkman
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'icts\kbarkman')
ALTER ROLE stanford_developers ADD MEMBER [icts\kbarkman]
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'icts\dprasad')
ALTER ROLE stanford_developers ADD MEMBER [icts\dprasad]
GO



