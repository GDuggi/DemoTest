CREATE ROLE service_broker_cnfmgr 
GO
IF NOT EXISTS(SELECT 1 FROM master.sys.sql_logins WHERE name = 'AFFMSG')
CREATE LOGIN [AFFMSG] WITH PASSWORD=N'AFFMSG', CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE name = 'AFFMSG')
CREATE USER [AFFMSG] FOR LOGIN [AFFMSG] WITH DEFAULT_SCHEMA=[AFFMSG]
GO

GRANT SELECT ON sys.conversation_endpoints TO service_broker_cnfmgr
GO
ALTER ROLE db_ddladmin ADD MEMBER service_broker_cnfmgr
GO
ALTER AUTHORIZATION ON SCHEMA::AFFMSG TO [AFFMSG]
GO
GRANT EXECUTE ON SCHEMA::[AFFMSG] TO service_broker_cnfmgr
GO
GRANT DELETE ON SCHEMA::[AFFMSG] TO service_broker_cnfmgr
GO
GRANT UPDATE ON SCHEMA::[AFFMSG] TO service_broker_cnfmgr
GO
GRANT SELECT ON SCHEMA::[AFFMSG] TO service_broker_cnfmgr
GO
GRANT INSERT ON SCHEMA::[AFFMSG] TO service_broker_cnfmgr
GO
GRANT CREATE PROCEDURE TO service_broker_cnfmgr
GO
GRANT ALTER TO service_broker_cnfmgr
GO
GRANT CREATE TABLE TO service_broker_cnfmgr
GO
GRANT CREATE VIEW TO service_broker_cnfmgr
GO
GRANT ALTER ON SCHEMA::[AFFMSG] TO service_broker_cnfmgr
GO
GRANT SELECT ON SCHEMA::[ConfirmMgr] TO service_broker_cnfmgr
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'AFFMSG')
ALTER ROLE service_broker_cnfmgr ADD MEMBER AFFMSG
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'rnell')
ALTER ROLE service_broker_cnfmgr ADD MEMBER rnell
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'icts\kbarkman')
ALTER ROLE [service_broker_cnfmgr] ADD MEMBER [icts\kbarkman]
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'icts\dprasad')
ALTER ROLE [service_broker_cnfmgr] ADD MEMBER [icts\dprasad]
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'kbarkman')
ALTER ROLE [service_broker_cnfmgr] ADD MEMBER [kbarkman]
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'cnfmgrsvc')
ALTER ROLE service_broker_cnfmgr ADD MEMBER cnfmgrsvc
GO

IF EXISTS (SELECT 1 FROM sys.database_principals WHERE name = 'cm_admin')
ALTER ROLE service_broker_cnfmgr ADD MEMBER cm_admin
GO