<#
.SYNOPSIS
	SUMMARY

.DESCRIPTION
	PS Script used to checks if the FileStream Access is Enable on SQL Server

.PARAMETERS $dbname
	SUMMARY

.INPUTS
	
.OUTPUTS
	Log Results 
	Log Error if is necessary

.FUNCTIONALITY
	

.EXAMPLE
	

.NOTES
	Author:			Javier Montero  - 11/16/2015
    Version:		1.0	
	Compatibility	PS 2.0 or Higher
	SQL Ver:		SQL Server 2008R2 or Higher
	TO GET HELP OR ANY NOTE HERE
	TYPE 
	GET-HELP .\FileStreamAccess_Validation.ps1
#>

param(
	
	[Parameter(Position=0, Mandatory=$true)]
	[string]$srvinstance,
	[Parameter(Position=1, Mandatory=$true)]
	[string]$dbuser,
	[Parameter(Position=2, Mandatory=$true)]
	[string]$dbuspassw

)

$server         = $srvinstance
$user           = $dbuser
$passw          = $dbuspassw
$db_name        = "master"
$scriptspath    = Split-Path -Parent $MyInvocation.MyCommand.Definition

# trap errors
$errors = $scriptspath+"\errors.log"
trap
{
  "______________________" | out-file $errors -append;
  "ERROR SCRIPTING " | out-file $errors -append;
  get-date | out-file $errors -append;
  "ERROR: " + $_ | out-file $errors -append;
  "`$server = $server" | out-file $errors -append;
  "`$database = $db_name" | out-file $errors -append;
  #"`$scripts = $scripts" | out-file $errors -append;
  throw "ERROR!!!!: See $errors"
}

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null #<-- Powershell V 2.0 Higher

$srv 		= New-Object "Microsoft.SqlServer.Management.SMO.Server" $server

#Login credentials
$srv.ConnectionContext.LoginSecure = $false;
#$credential = Get-Credential
$SqlUPwd = ConvertTo-SecureString $passw -AsPlainText -Force; #Converting Password text to Secury credentials
$srv.ConnectionContext.set_Login($user);
$srv.ConnectionContext.set_SecurePassword($SqlUPwd);

Write-Host $scriptspath
$pathfile = $scriptspath



function ValidateFileStreamAccess($serverobj, $dbobj, $userobj, $passobj, $fileobj){
			
			
	if(Test-Path -Path $scriptspath\"FileStream\logs" -PathType Container)
	{
		Write-Host "Removing Previous Log Files If Exists"	
		Remove-Item $scriptspath\"FileStream\logs" -Include .log
		Write-Host "Performing Database Process"	
			Import-module SQLPS -DisableNameChecking
			Invoke-Sqlcmd -InputFile $fileobj `
			-ServerInstance $serverobj `
			-Database $dbobj `
			-Username $userobj `
			-Password $passobj `
	        | Out-File -filepath $scriptspath\"FileStream\logs\fslog.log"
		Write-Host "Process Finished Please Check the Logs Files"	
	}	
	else
	{
		Write-Host "Creating Logs Folder"	
		New-Item $scriptspath\"FileStream\logs" -ItemType directory
		Write-Host "Performing Database Process"	
			Import-module SQLPS -DisableNameChecking
			Invoke-Sqlcmd -InputFile $fileobj `
			-ServerInstance $serverobj `
			-Database $dbobj `
			-Username $userobj `
			-Password $passobj `
			| Out-File -filepath $scriptspath\"FileStream\logs\fslog.log"
		Write-Host "Process Finished Please Check the Logs Files"	
	}	
	
			
	#Set-Location -Path .. -PassThru		
	#cd c:
}

if($pathfile -ne $null)
{
	$pathlist = Get-Item -Path $pathfile
	$fspath = $pathfile+"\FileStream"

		if(Test-Path $fspath -PathType Container)
		{
			Set-Location $fspath
			Write-Host "If you need help about the parameters, Please Use the cmdlet Get-Help .\FileStreamAccess_Validation.ps1"
			$list = Get-ChildItem $fspath | Where-Object{$_.Name -eq "Filestream_Validation.sql"}
			
			Foreach($script in $list)
			{
				if($script -ne $null)
				{
					$text = Get-Content $script
					[string]$value = "$($fspath)\$script"		
					Write-Host "Validating FileStream Access...."
					Write-Host $value
					ValidateFileStreamAccess $server $db_name $user $passw $value
					Set-Location -Path .. -PassThru
					
				}	
				else
				{
					Write-Host ".SQL Script Don't exists please validate"
				}
			}
		}
	else
	{
		Write-Host "Failed"
	}
	

	
}

