<#

.SYNOPSIS
	SCRIPT DEVELOPED TO GET ALL DATABASE OBJECTS SCRIPT FROM SQL SERVER

.DESCRIPTION
	PS Script used to Build Confirmations Manager Database on SQL Server

.PARAMETERS 
	$dbuser       :  DatabaseUser with credentials to logon as sysadmin
	$dbusupassw   :  Password of Database User
	$srvinstance  :  SQL Server Instance to work
	

.INPUTS
	
.OUTPUTS
	SchemaName.TableName.sql
	Log Results error.log
	Log Error if is necessary


.EXAMPLE
 Ps c:\> .\CreateDataBase.ps1

.NOTES
	Author:			Javier Montero  - 11/16/2015
    Version:		1.0	
	Compatibility	PS 2.0 or Higher
	SQL Ver:		SQL Server 2008R2 or Higher
	TO GET HELP OR ANY NOTE HERE
	TYPE 
	GET-HELP .\CreateDataBase.ps1
	
#>


param(
	
	[Parameter(Position=1, Mandatory=$true)]
	[string]$dbuser,
	[Parameter(Position=2, Mandatory=$true)]
	[string]$dbuspassw,
	[Parameter(Position=0, Mandatory=$true)]
	[string]$srvinstance

)

$server         = $srvinstance
$user           = $dbuser
$passw          = $dbuspassw
$db_name        = "master"
$scriptspath    = Split-Path -Parent $MyInvocation.MyCommand.Definition

# trap errors
$errors = $scriptspath+"\errors.log"
trap
{
  "______________________" | out-file $errors -append;
  "ERROR SCRIPTING " | out-file $errors -append;
  get-date | out-file $errors -append;
  "ERROR: " + $_ | out-file $errors -append;
  "`$server = $server" | out-file $errors -append;
  "`$database = $db_name" | out-file $errors -append;
  #"`$scripts = $scripts" | out-file $errors -append;
  throw "ERROR!!!!: See $errors"
}

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null #<-- Powershell V 2.0 Higher

$srv 		= New-Object "Microsoft.SqlServer.Management.SMO.Server" $server

#Login credentials
$srv.ConnectionContext.LoginSecure = $false;
#$credential = Get-Credential
$SqlUPwd = ConvertTo-SecureString $passw -AsPlainText -Force; #Converting Password text to Secury credentials
$srv.ConnectionContext.set_Login($user);
$srv.ConnectionContext.set_SecurePassword($SqlUPwd);

$pathfile = $scriptspath



function RunCommands($serverobj, $dbobj, $userobj, $passobj, $fileobj)
{

	
	if(Test-Path -Path $scriptspath\"Database\logs" -PathType Container)
	{
		Write-Host "Removing Previous Log Files If Exists"
		Remove-Item $scriptspath\"Database\logs" -Include .log 	
		Write-Host "Creating Confirmations Manager Database"
		Import-Module SQLPS -DisableNameChecking
		
		Invoke-Sqlcmd -InputFile $fileobj `
		 -ServerInstance $serverobj `
		 -Database $dbobj `
		 -Username $userobj `
		 -Password $passobj `
	     | Out-File -filepath $scriptspath\"Database\logs\dblog.log"
		
		Write-Host "Process Finished Please Check the Logs Files"	
	}		
	else
	{
		Write-Host "Logs Folder Don't Exists.. Creating Logs Folder"	
		New-Item $scriptspath\"Database\logs" -ItemType directory
		Write-Host "Creating Confirmations Manager Database"
		Import-module SQLPS -DisableNameChecking
		
		Invoke-Sqlcmd -InputFile $fileobj `
			-ServerInstance $serverobj `
			-Database $dbobj `
			-Username $userobj `
			-Password $passobj `
			| Out-File -filepath $scriptspath\"Database\logs\dblog.log"
		
		Write-Host "Process Finished Please Check the Logs Files"	
	}
			
		
			

}

# Main Program


if($pathfile -ne $null)
{
	$pathlist = Get-Item -Path $pathfile
	$fspath = $pathfile+"\Database"
	
	if(Test-Path $fspath -PathType Container)
	{
		Set-Location $fspath
		$list = Get-ChildItem $fspath | Where-Object{$_.Extension -eq ".sql"}
		Foreach($script in $list)
		{
		
			if($script -ne $null)
			{
				$text = Get-Content $script
				
				[string]$value = "$($fspath)\$script"		
				RunCommands $server $db_name $user $passw $value
				Set-Location -Path .. -PassThru
			
			}
		
		}
	}
		
	
}
