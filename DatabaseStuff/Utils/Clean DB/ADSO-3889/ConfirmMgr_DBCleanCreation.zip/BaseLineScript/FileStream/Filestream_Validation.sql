declare 
@sql		nvarchar(max),
@ret		int

BEGIN

	SELECT @ret = cast(value_in_use as int) FROM sys.configurations WHERE name = 'filestream access level'
	IF @ret = 2
		BEGIN
			SELECT 'FILESTREAM ACCESS IS ENABLED'
		END
	ELSE
		BEGIN
			SET @sql = N'EXEC sp_configure '
			SET @sql = @sql + N'''' 
			SET @sql = @sql + N'FILESTREAM_ACCESS_LEVEL'
			SET @sql = @sql + N''''
			SET @sql = @sql + N','
			SET @sql = @sql + N''''
			SET @sql = @sql + N'2'
			SET @sql = @sql + N''''
			SET @sql = @sql + N' RECONFIGURE WITH OVERRIDE'
			--SELECT 'EXECUTING ' + @sql
			exec sp_executesql @sql
			SELECT 'FILESTREAM ACCESS ENABLE SUCCESSFULLY'
		END
    
END
GO
SELECT 'FILESTREAM ACCESS VALIDATION PROCESS FINISHED'
GO
