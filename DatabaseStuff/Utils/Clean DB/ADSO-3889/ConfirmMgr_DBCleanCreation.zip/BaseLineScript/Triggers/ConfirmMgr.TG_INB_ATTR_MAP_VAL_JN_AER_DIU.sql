SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER OFF
GO

CREATE TRIGGER [ConfirmMgr].[TG_INB_ATTR_MAP_VAL_JN_AER_DIU]
ON [ConfirmMgr].[INB_ATTRIB_MAP_VAL]
AFTER INSERT, UPDATE, DELETE
AS

/******************************************************************************
*
* AUTHOR:		JAVIER MONTERO - 07/16/2015
* DB:			SQL SERVER 2008 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  TRIGGER FOR DELETE ACTIONS ON TABLE INB_ATTRIB_MAP_VAL
* DEPENDECIES:  TABLE INB_ATTRIB_MAP_VAL_JN IS REQUIERED
*
*******************************************************************************/
DECLARE 
@tmp_username		varchar(100),
@tmp_hostname		varchar(100),
@errormsg			varchar(4000),
@rows				int
BEGIN
	SET NOCOUNT ON;
	/*Here, the trigger get the hostname and user name that execute the deleted action*/
	
	SELECT @tmp_hostname = HOST_NAME(), @tmp_username = SUSER_NAME();
			
			/*If the user name and host name are null, the trigger don't execute any action then rollback the delete process*/
			IF @tmp_username IS NULL AND @tmp_hostname IS NULL
			BEGIN
				SET @errormsg = 'INSERT ON TRADE_SUMMARY_JN WAS ROLLBACKED BECAUSE USER_NAME OR HOST_NAME IS NULL'
				RAISERROR(@errormsg, 0,29000)
				
				ROLLBACK TRAN
				RETURN
			END			
	
		/*UPDATE*/
		IF EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
			BEGIN
			/*IF the ROWS exists in the inserted and exists in the deleted table the process shoot the action 
			to INSERT the values in the table INB_ATTRIB_MAP_VAL_JN*/
			   INSERT ConfirmMgr.INB_ATTRIB_MAP_VAL_JN(
			 	 jn.JN_ORACLE_USER,
				 jn.JN_DATETIME,
				 jn.JN_OPERATION,
				 jn.JN_HOST_NAME,
				 jn.ID,
				 jn.INB_ATTRIB_CODE,
				 jn.MAPPED_VALUE,
				 jn.DESCR,
				 jn.ACTIVE_FLAG
				)
				SELECT 
					@tmp_username,
					GETDATE(),
					'U',
					@tmp_hostname,
					d.ID,
					d.INB_ATTRIB_CODE,
					d.MAPPED_VALUE,
					d.DESCR,
					d.ACTIVE_FLAG
				FROM inserted d
				INNER JOIN ConfirmMgr.INB_ATTRIB_MAP_VAL b ON d.ID = b.ID
				RETURN
		    END
		
		/*INSERT*/
		IF EXISTS(SELECT 1 FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)			
			BEGIN
			/*If the ROWS exists in the inserted and not exists in the deleted table the process shoot the action 
			to INSERT the values in the table INB_ATTRIB_MAP_VAL_JN*/
			  INSERT ConfirmMgr.INB_ATTRIB_MAP_VAL_JN(
			 	 jn.JN_ORACLE_USER,
				 jn.JN_DATETIME,
				 jn.JN_OPERATION,
				 jn.JN_HOST_NAME,
				 jn.ID,
				 jn.INB_ATTRIB_CODE,
				 jn.MAPPED_VALUE,
				 jn.DESCR,
				 jn.ACTIVE_FLAG
				)
			SELECT 
				@tmp_username,
				GETDATE(),
				'I',
				@tmp_hostname,
				d.ID,
				d.INB_ATTRIB_CODE,
				d.MAPPED_VALUE,
				d.DESCR,
				d.ACTIVE_FLAG
			FROM inserted d
			RETURN
			END

		 /*DELETE*/
		 IF NOT EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
			/*If the ROWS exists in the deleted table the process shoot the action to INSERT the values in the table INB_ATTRIB_MAP_VAL_JN*/
			BEGIN
				INSERT ConfirmMgr.INB_ATTRIB_MAP_VAL_JN(
			 	 jn.JN_ORACLE_USER,
				 jn.JN_DATETIME,
				 jn.JN_OPERATION,
				 jn.JN_HOST_NAME,
				 jn.ID,
				 jn.INB_ATTRIB_CODE,
				 jn.MAPPED_VALUE,
				 jn.DESCR,
				 jn.ACTIVE_FLAG
				)
			SELECT 
				@tmp_username,
				GETDATE(),
				'D',
				@tmp_hostname,
				d.ID,
				d.INB_ATTRIB_CODE,
				d.MAPPED_VALUE,
				d.DESCR,
				d.ACTIVE_FLAG
				FROM deleted d
			RETURN
			END

END

GO
