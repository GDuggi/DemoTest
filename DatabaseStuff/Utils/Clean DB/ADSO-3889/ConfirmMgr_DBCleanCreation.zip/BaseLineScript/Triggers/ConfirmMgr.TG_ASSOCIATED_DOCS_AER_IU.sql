SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [ConfirmMgr].[TG_ASSOCIATED_DOCS_AER_IU]
  -- AQ PayLoad: VERSION | ID | INBOUND_DOCS_ID | DOC_STATUS_CODE | TRADE_RQMT_ID
  on [ConfirmMgr].[ASSOCIATED_DOCS]
  after insert, update
as

  if (@@rowcount = 0)
	return;
	
  DECLARE @payloads as AFFMSG.TABLE_CHANGE_SEND_MSG_TYPE;  
  
  insert into @payloads
  select distinct 
        '1' + '|' + 
        cast(id as varchar) +'|' + 
        cast(inbound_docs_id as varchar ) +'|' + 
        doc_status_code +'|' +
        cast(trade_rqmt_id as varchar )               
   from inserted;
   
  EXECUTE AFFMSG.TABLE_CHANGE_SEND_MSGS 'CONFIRMMGR.ASSOCIATED_DOCS', @payloads
GO
