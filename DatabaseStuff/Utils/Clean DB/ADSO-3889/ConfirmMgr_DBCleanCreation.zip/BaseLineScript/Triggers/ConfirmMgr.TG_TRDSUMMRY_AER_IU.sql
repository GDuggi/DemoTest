SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [ConfirmMgr].[TG_TRDSUMMRY_AER_IU]
  -- AQ PayLoad: VERSION | ID | TRADE_ID | TRANSACTION_SEQ | LAST_UPDATE_TIMESTAMP_GMT | LAST_TRD_EDIT_TIMESTAMP_GMT
  on [ConfirmMgr].[TRADE_SUMMARY]
  after insert, update
as  
  DECLARE @payload varchar(512);    
  BEGIN

  if (@@rowcount = 0)
	return;

  set nocount on

  DECLARE @payloads as AFFMSG.TABLE_CHANGE_SEND_MSG_TYPE;  

  insert into @payloads
  select '1' + '|' + 
        cast(i.id as varchar) +'|' + 
        cast(i.trade_id as varchar ) +'|' + 
        cast(ts.transaction_seq as varchar ) +'|' + 
        AFFMSG.CVT_DATETIME_TO_DDMONYYY_HH24MISS( i.last_update_timestamp_gmt ) + '|' +
        AFFMSG.CVT_DATETIME_TO_DDMONYYY_HH24MISS( i.last_trd_edit_timestamp_gmt )  
   from inserted i
   INNER JOIN ConfirmMgr.TRADE_SUMMARY ts
   ON i.ID = ts.ID

  EXECUTE AFFMSG.TABLE_CHANGE_SEND_MSGS 'CONFIRMMGR.TRADE_SUMMARY', @payloads
  
  END



GO
EXEC sp_settriggerorder @triggername=N'[ConfirmMgr].[TG_TRDSUMMRY_AER_IU]', @order=N'Last', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[ConfirmMgr].[TG_TRDSUMMRY_AER_IU]', @order=N'Last', @stmttype=N'UPDATE'
GO
