SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [ConfirmMgr].[TG_INBOUND_DOC_JN_AER_DIU]
ON [ConfirmMgr].[INBOUND_DOCS]
AFTER INSERT, UPDATE, DELETE
AS

/******************************************************************************
*
* AUTHOR:		JAVIER MONTERO - 07/16/2015
* DB:			SQL SERVER 2008 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  TRIGGER FOR DELETE ACTIONS ON TABLE INBOUND_DOCS
* DEPENDECIES:  TABLE INBOUND_DOCS_JN IS REQUIERED
*
*******************************************************************************/
DECLARE 
@tmp_username		VARCHAR(100),
@tmp_hostname		VARCHAR(100),
@errormsg			VARCHAR(4000),
@rows				INT;
BEGIN
	SET NOCOUNT ON;
	/*Here, the trigger get the hostname and user name that execute the deleted action*/
	
	SELECT @tmp_hostname = HOST_NAME(), @tmp_username = SUSER_NAME();
			
			/*If the user name and host name are null, the trigger don't execute any action then rollback the delete process*/
			IF @tmp_username IS NULL AND @tmp_hostname IS NULL
			BEGIN
				SET @errormsg = 'INSERT ON TRADE_SUMMARY_JN WAS ROLLBACKED BECAUSE USER_NAME OR HOST_NAME IS NULL';
				RAISERROR(@errormsg, 0,29000);
				
				ROLLBACK TRANSACTION;
				RETURN;
			END;	
	
		/*UPDATE*/
		IF EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
			BEGIN
			/*IF the ROWS exists in the inserted and exists in the deleted table the process shoot the action 
			to INSERT the values in the table INBOUND_DOCS_JN*/
			INSERT ConfirmMgr.INBOUND_DOCS_JN(
			 	 jn.JN_ORACLE_USER,
				 jn.JN_DATETIME,
				 jn.JN_OPERATION,
				 jn.JN_HOST_NAME,
				 jn.ID,
				 jn.CALLER_REF,
			     jn.SENT_TO,
                 jn.RCVD_TS,
				 jn.FILE_NAME,
				 jn.SENDER,
				 jn.CMT,
				 jn.DOC_STATUS_CODE,
			     jn.HAS_AUTO_ASCTED_FLAG,
				 jn.MAPPED_CPTY_SN,
				 jn.JOB_REF,
				 jn.PROC_FLAG,
				 jn.MAPPED_BRKR_SN,
				 jn.MAPPED_CDTY_CODE
				)
			SELECT 
				@tmp_username,
				GETDATE(),
				'U',
				@tmp_hostname,
				d.ID,
				d.CALLER_REF,
			    d.SENT_TO,
                d.RCVD_TS,
				d.FILE_NAME,
				d.SENDER,
				d.CMT,
				d.DOC_STATUS_CODE,
			    d.HAS_AUTO_ASCTED_FLAG,
				d.MAPPED_CPTY_SN,
				d.JOB_REF,
				d.PROC_FLAG,
				d.MAPPED_BRKR_SN,
				d.MAPPED_CDTY_CODE
			FROM inserted d
			INNER JOIN ConfirmMgr.INBOUND_DOCS b ON d.ID = b.ID;
			RETURN;
		    END;
		
		/*INSERT*/
		IF EXISTS(SELECT 1 FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)			
			BEGIN
			/*If the ROWS exists in the inserted and not exists in the deleted table the process shoot the action 
			to INSERT the values in the table INBOUND_DOCS_JN*/
			  INSERT ConfirmMgr.INBOUND_DOCS_JN(
			 	 jn.JN_ORACLE_USER,
				 jn.JN_DATETIME,
				 jn.JN_OPERATION,
				 jn.JN_HOST_NAME,
				 jn.ID,
				 jn.CALLER_REF,
			     jn.SENT_TO,
                 jn.RCVD_TS,
				 jn.FILE_NAME,
				 jn.SENDER,
				 jn.CMT,
				 jn.DOC_STATUS_CODE,
			     jn.HAS_AUTO_ASCTED_FLAG,
				 jn.MAPPED_CPTY_SN,
				 jn.JOB_REF,
				 jn.PROC_FLAG,
				 jn.MAPPED_BRKR_SN,
				 jn.MAPPED_CDTY_CODE
				)
			SELECT 
				@tmp_username,
				GETDATE(),
				'I',
				@tmp_hostname,
				d.ID,
				d.CALLER_REF,
			    d.SENT_TO,
                d.RCVD_TS,
				d.FILE_NAME,
				d.SENDER,
				d.CMT,
				d.DOC_STATUS_CODE,
			    d.HAS_AUTO_ASCTED_FLAG,
				d.MAPPED_CPTY_SN,
				d.JOB_REF,
				d.PROC_FLAG,
				d.MAPPED_BRKR_SN,
				d.MAPPED_CDTY_CODE
			FROM inserted d;
			
			RETURN;
			END;

		 /*DELETE*/
		 IF NOT EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
			/*If the ROWS exists in the deleted table the process shoot the action to INSERT the values in the table INBOUND_DOCS_JN*/
			BEGIN
				 INSERT ConfirmMgr.INBOUND_DOCS_JN(
			 	 jn.JN_ORACLE_USER,
				 jn.JN_DATETIME,
				 jn.JN_OPERATION,
				 jn.JN_HOST_NAME,
				 jn.ID,
				 jn.CALLER_REF,
			     jn.SENT_TO,
                 jn.RCVD_TS,
				 jn.FILE_NAME,
				 jn.SENDER,
				 jn.CMT,
				 jn.DOC_STATUS_CODE,
			     jn.HAS_AUTO_ASCTED_FLAG,
				 jn.MAPPED_CPTY_SN,
				 jn.JOB_REF,
				 jn.PROC_FLAG,
				 jn.MAPPED_BRKR_SN,
				 jn.MAPPED_CDTY_CODE
				)
			SELECT 
				@tmp_username,
				GETDATE(),
				'D',
				@tmp_hostname,
				d.ID,
				d.CALLER_REF,
			    d.SENT_TO,
                d.RCVD_TS,
				d.FILE_NAME,
				d.SENDER,
				d.CMT,
				d.DOC_STATUS_CODE,
			    d.HAS_AUTO_ASCTED_FLAG,
				d.MAPPED_CPTY_SN,
				d.JOB_REF,
				d.PROC_FLAG,
				d.MAPPED_BRKR_SN,
				d.MAPPED_CDTY_CODE
				FROM deleted d;
			RETURN;
			END;

END;

GO
