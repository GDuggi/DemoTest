SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [ConfirmMgr].[TG_TRADE_APPR_JN_AER_DUI]
   ON  [ConfirmMgr].[TRADE_APPR]
   AFTER INSERT,DELETE,UPDATE
AS 

DECLARE
@tmp_username		VARCHAR(100),
@tmp_hostname		VARCHAR(100),
@errormsg			VARCHAR(4000)

BEGIN
	
	if (@@rowcount = 0)
		return;

	SET NOCOUNT ON;

    SELECT @tmp_hostname = HOST_NAME(), @tmp_username = SUSER_NAME();
			
	/*If the user name and host name are null, the trigger don't execute any action then rollback the delete process*/
	IF @tmp_username IS NULL AND @tmp_hostname IS NULL
	BEGIN
		SET @errormsg = 'INSERT ON TRADE_RQMT_JN WAS ROLLBACKED BECAUSE USER_NAME OR HOST_NAME IS NULL';
		RAISERROR(@errormsg, 0,29000);
				
		ROLLBACK TRANSACTION;
		RETURN;
	END;		

	-- Handle insert/update case where rows will be either just in new or in both.
	insert into ConfirmMgr.TRADE_APPR_JN (
		[JN_ORACLE_USER],
		[JN_DATETIME],
		[JN_OPERATION],
		[JN_HOST_NAME],
		[ID],
		[TRADE_ID],
		[APPR_FLAG],
		[APPR_TIMESTAMP_GMT],
		[APPR_BY_USERNAME] 
	)
	select @tmp_username as JN_ORACLE_USER,
		   GETDATE() as JN_DATETIME,
		   case 
				when old.id is null then 'I'				
				else 'U'
		   end as JN_OPERATION,
		   @tmp_hostname,
		   new.ID,
		   new.TRADE_ID,
		   new.APPR_FLAG,
		   new.APPR_TIMESTAMP_GMT,
		   new.APPR_BY_USERNAME
		from inserted new
			left outer join deleted old on new.id = old.id	

	-- Handle deleted case where rows will only be on old
	insert into ConfirmMgr.TRADE_APPR_JN (
		[JN_ORACLE_USER],
		[JN_DATETIME],
		[JN_OPERATION],
		[JN_HOST_NAME],
		[ID],
		[TRADE_ID],
		[APPR_FLAG],
		[APPR_TIMESTAMP_GMT],
		[APPR_BY_USERNAME] 
	)
	select @tmp_username as JN_ORACLE_USER,
		   GETDATE() as JN_DATETIME,
		   'D' as JN_OPERATION,						   
		   @tmp_hostname,
		   old.ID,
		   old.TRADE_ID,
		   old.APPR_FLAG,
		   old.APPR_TIMESTAMP_GMT,
		   old.APPR_BY_USERNAME
		from deleted old
			left outer join inserted new on old.id = new.id	
		where new.id is null; -- get only the deleted rows
END

GO
