SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [ConfirmMgr].[TG_TRADERQMT_IIU]
   ON  [ConfirmMgr].[TRADE_RQMT]
   INSTEAD OF INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- for insert 
	INSERT INTO [ConfirmMgr].[TRADE_RQMT]
           ([ID]
           ,[TRADE_ID]
           ,[RQMT_TRADE_NOTIFY_ID]
           ,[RQMT]
           ,[STATUS]
           ,[COMPLETED_DT]
           ,[COMPLETED_TIMESTAMP_GMT]
           ,[REFERENCE]
           ,[CANCEL_TRADE_NOTIFY_ID]
           ,[CMT]
           ,[SECOND_CHECK_FLAG])
     select i.ID
           ,i.TRADE_ID
           ,i.RQMT_TRADE_NOTIFY_ID
           ,i.RQMT
           ,i.STATUS
           ,ISNULL(i.COMPLETED_DT, CONVERT(DATETIME,Convert(DATE,GETDATE())) )
           ,i.COMPLETED_TIMESTAMP_GMT
           ,i.REFERENCE
           ,i.CANCEL_TRADE_NOTIFY_ID
           ,i.CMT
           ,i.SECOND_CHECK_FLAG
		from inserted i 
		left outer join deleted d on d.ID = i.ID 
	 where d.TRADE_ID is null;
		
    -- for update
	update t		
		set t.TRADE_ID = i.TRADE_ID,
			t.RQMT_TRADE_NOTIFY_ID = i.RQMT_TRADE_NOTIFY_ID,
			t.RQMT = i.RQMT,
			t.STATUS = i.STATUS,
			t.COMPLETED_DT = 
				CASE 
					WHEN d.STATUS <> i.STATUS and d.COMPLETED_DT = i.COMPLETED_DT and d.COMPLETED_DT is not null 
						then CONVERT(DATETIME,Convert(DATE,GETDATE()))
					when i.COMPLETED_DT is NULL
						then CONVERT(DATETIME,Convert(DATE,GETDATE()))
					ELSE 
						i.COMPLETED_DT
				end,									
			t.COMPLETED_TIMESTAMP_GMT = i.COMPLETED_TIMESTAMP_GMT,
			t.REFERENCE = i.REFERENCE,
			t.CANCEL_TRADE_NOTIFY_ID = i.CANCEL_TRADE_NOTIFY_ID,
			t.CMT = i.CMT,
			t.SECOND_CHECK_FLAG = i.SECOND_CHECK_FLAG
	from TRADE_RQMT t
		inner join inserted i on i.ID = t.ID
		inner join DELETED d on d.ID = i.ID

END

GO
