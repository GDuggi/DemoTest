SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TRIGGER [ConfirmMgr].[TG_TRADE_DATA_JN_DIU]
ON [ConfirmMgr].[TRADE_DATA]
AFTER INSERT,UPDATE, DELETE
AS
/******************************************************************************
*
* AUTHOR:		JAVIER MONTERO - 10/26/2015
* DB:			SQL SERVER 2008 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  TRIGGER FOR INSERT ACTIONS ON TABLE TRADE_DATE
* DEPENCIES:    TABLE TRADE_DATE_JN IS REQUIERED
*
*******************************************************************************/
DECLARE
@tmp_hostname		varchar(100),
@tmp_username		varchar(100),
@errormsg			nvarchar(2000)
BEGIN
			SELECT @tmp_hostname = HOST_NAME(), @tmp_username = SUSER_NAME();
			/*If the user name and host name are null, the trigger don't execute any action then rollback the delete process*/
			IF @tmp_username IS NULL AND @tmp_hostname IS NULL
			BEGIN
				SET @errormsg = 'INSERT ON TRADE_DATA_JN WAS ROLLBACKED BECAUSE USER_NAME OR HOST_NAME IS NULL'
				RAISERROR(@errormsg, 0,29000)
				
				ROLLBACK TRAN
				RETURN
			END	

			/*UPDATE ACTION
			If the ROWS exists in the inserted & Exists in the delEted table the process raise the action to INSERT the values in the table TRADE_DATE_JN*/
			IF EXISTS(SELECT * FROM inserted) AND EXISTS(SELECT * FROM deleted)
			BEGIN
				INSERT ConfirmMgr.TRADE_DATA_JN
				(	JN_ORACLE_USER,
					JN_DATETIME,
					JN_OPERATION,
					JN_HOST_NAME,
					ID, 
					TRADE_ID,
					INCEPTION_DT,
					CDTY_CODE,
					TRADE_DT,
					XREF,
					CPTY_SN,
					QTY_TOT,
					LOCATION_SN,
					PRICE_DESC,
					START_DT,
					END_DT,
					BOOK,
					TRADE_TYPE_CODE,
					STTL_TYPE,
					BROKER_SN,
					BUY_SELL_IND,
					REF_SN,
					TRADE_STAT_CODE,
					CDTY_GRP_CODE,
					BROKER_PRICE,
					OPTN_STRIKE_PRICE,
					OPTN_PREM_PRICE,
					OPTN_PUT_CALL_IND,
					PERMISSION_KEY,
					PROFIT_CENTER,
					CPTY_LEGAL_NAME,
					QTY_DESC,
					TRADE_DESC,
					BOOKING_CO_SN,
					BOOKING_CO_ID,
					CPTY_ID,
					BROKER_LEGAL_NAME,
					BROKER_ID,
					TRANSPORT_DESC,
					TRADER				 
				)
				SELECT
				@tmp_username,
				GETDATE(),
				'U',
				@tmp_hostname,
				i.ID, 
				i.TRADE_ID,
				i.INCEPTION_DT,
				i.CDTY_CODE,
				i.TRADE_DT,
				i.XREF,
				i.CPTY_SN,
				i.QTY_TOT,
				i.LOCATION_SN,
				i.PRICE_DESC,
				i.START_DT,
				i.END_DT,
				i.BOOK,
				i.TRADE_TYPE_CODE,
				i.STTL_TYPE,
				i.BROKER_SN,
				i.BUY_SELL_IND,
				i.REF_SN,
				i.TRADE_STAT_CODE,
				i.CDTY_GRP_CODE,
				i.BROKER_PRICE,
				i.OPTN_STRIKE_PRICE,
				i.OPTN_PREM_PRICE,
				i.OPTN_PUT_CALL_IND,
				i.PERMISSION_KEY,
				i.PROFIT_CENTER,
				i.CPTY_LEGAL_NAME,
				i.QTY_DESC,
				i.TRADE_DESC,
				i.BOOKING_CO_SN,
				i.BOOKING_CO_ID,
				i.CPTY_ID,
				i.BROKER_LEGAL_NAME,
				i.BROKER_ID,
				i.TRANSPORT_DESC,
				i.TRADER			
				FROM inserted i
				INNER JOIN ConfirmMgr.TRADE_DATA td
				ON i.ID = td.ID 
				RETURN
			END
			

			/*DELETE ACTION
			If the ROWS Not exists in the inserted & Exists in the deleted table the process raise the action to INSERT the values in the table TRADE_DATE_JN*/
			IF EXISTS(SELECT * FROM deleted) AND NOT EXISTS(SELECT * FROM inserted)
			BEGIN
				INSERT ConfirmMgr.TRADE_DATA_JN
				(
					JN_ORACLE_USER,
					JN_DATETIME,
					JN_OPERATION,
					JN_HOST_NAME,
					ID, 
					TRADE_ID,
					INCEPTION_DT,
					CDTY_CODE,
					TRADE_DT,
					XREF,
					CPTY_SN,
					QTY_TOT,
					LOCATION_SN,
					PRICE_DESC,
					START_DT,
					END_DT,
					BOOK,
					TRADE_TYPE_CODE,
					STTL_TYPE,
					BROKER_SN,
					BUY_SELL_IND,
					REF_SN,
					TRADE_STAT_CODE,
					CDTY_GRP_CODE,
					BROKER_PRICE,
					OPTN_STRIKE_PRICE,
					OPTN_PREM_PRICE,
					OPTN_PUT_CALL_IND,
					PERMISSION_KEY,
					PROFIT_CENTER,
					CPTY_LEGAL_NAME,
					QTY_DESC,
					TRADE_DESC,
					BOOKING_CO_SN,
					BOOKING_CO_ID,
					CPTY_ID,
					BROKER_LEGAL_NAME,
					BROKER_ID,
					TRANSPORT_DESC,
					TRADER				 
				)
				SELECT
				@tmp_username,
				GETDATE(),
				'D',
				@tmp_hostname,
				i.ID, 
				i.TRADE_ID,
				i.INCEPTION_DT,
				i.CDTY_CODE,
				i.TRADE_DT,
				i.XREF,
				i.CPTY_SN,
				i.QTY_TOT,
				i.LOCATION_SN,
				i.PRICE_DESC,
				i.START_DT,
				i.END_DT,
				i.BOOK,
				i.TRADE_TYPE_CODE,
				i.STTL_TYPE,
				i.BROKER_SN,
				i.BUY_SELL_IND,
				i.REF_SN,
				i.TRADE_STAT_CODE,
				i.CDTY_GRP_CODE,
				i.BROKER_PRICE,
				i.OPTN_STRIKE_PRICE,
				i.OPTN_PREM_PRICE,
				i.OPTN_PUT_CALL_IND,
				i.PERMISSION_KEY,
				i.PROFIT_CENTER,
				i.CPTY_LEGAL_NAME,
				i.QTY_DESC,
				i.TRADE_DESC,
				i.BOOKING_CO_SN,
				i.BOOKING_CO_ID,
				i.CPTY_ID,
				i.BROKER_LEGAL_NAME,
				i.BROKER_ID,
				i.TRANSPORT_DESC,
				i.TRADER			
				FROM deleted i	
				RETURN			
			END
			

			/*INSERT ACTION
			If the ROWS exists in the inserted table the process raise the action to INSERT the values in the table TRADE_DATE_JN*/
			IF EXISTS(SELECT 1 FROM inserted) AND NOT EXISTS(SELECT * FROM deleted)
			BEGIN
				INSERT ConfirmMgr.TRADE_DATA_JN
				(
					JN_ORACLE_USER,
					JN_DATETIME,
					JN_OPERATION,
					JN_HOST_NAME,
					ID, 
					TRADE_ID,
					INCEPTION_DT,
					CDTY_CODE,
					TRADE_DT,
					XREF,
					CPTY_SN,
					QTY_TOT,
					LOCATION_SN,
					PRICE_DESC,
					START_DT,
					END_DT,
					BOOK,
					TRADE_TYPE_CODE,
					STTL_TYPE,
					BROKER_SN,
					BUY_SELL_IND,
					REF_SN,
					TRADE_STAT_CODE,
					CDTY_GRP_CODE,
					BROKER_PRICE,
					OPTN_STRIKE_PRICE,
					OPTN_PREM_PRICE,
					OPTN_PUT_CALL_IND,
					PERMISSION_KEY,
					PROFIT_CENTER,
					CPTY_LEGAL_NAME,
					QTY_DESC,
					TRADE_DESC,
					BOOKING_CO_SN,
					BOOKING_CO_ID,
					CPTY_ID,
					BROKER_LEGAL_NAME,
					BROKER_ID,
					TRANSPORT_DESC,
					TRADER				 
				)
				SELECT
				@tmp_username,
				GETDATE(),
				'I',
				@tmp_hostname,
				i.ID, 
				i.TRADE_ID,
				i.INCEPTION_DT,
				i.CDTY_CODE,
				i.TRADE_DT,
				i.XREF,
				i.CPTY_SN,
				i.QTY_TOT,
				i.LOCATION_SN,
				i.PRICE_DESC,
				i.START_DT,
				i.END_DT,
				i.BOOK,
				i.TRADE_TYPE_CODE,
				i.STTL_TYPE,
				i.BROKER_SN,
				i.BUY_SELL_IND,
				i.REF_SN,
				i.TRADE_STAT_CODE,
				i.CDTY_GRP_CODE,
				i.BROKER_PRICE,
				i.OPTN_STRIKE_PRICE,
				i.OPTN_PREM_PRICE,
				i.OPTN_PUT_CALL_IND,
				i.PERMISSION_KEY,
				i.PROFIT_CENTER,
				i.CPTY_LEGAL_NAME,
				i.QTY_DESC,
				i.TRADE_DESC,
				i.BOOKING_CO_SN,
				i.BOOKING_CO_ID,
				i.CPTY_ID,
				i.BROKER_LEGAL_NAME,
				i.BROKER_ID,
				i.TRANSPORT_DESC,
				i.TRADER			
				FROM inserted i	
				RETURN			
			END

END

GO
