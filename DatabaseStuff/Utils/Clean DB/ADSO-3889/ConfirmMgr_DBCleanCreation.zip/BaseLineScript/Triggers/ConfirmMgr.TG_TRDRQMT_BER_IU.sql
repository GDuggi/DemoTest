SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE TRIGGER [ConfirmMgr].[TG_TRDRQMT_BER_IU]
    ON [ConfirmMgr].[TRADE_RQMT]
    FOR INSERT, UPDATE
    AS
BEGIN
	
	if (@@rowcount = 0)
		return;

    SET NOCOUNT ON

	print 'TG_TRDRQMT_BER_IU - TRANSACTION_SEQ on Trade Summary'	
	
	update tr 
		set tr.COMPLETED_DT = CONVERT(DATETIME,Convert(DATE,GETDATE()))
		from ConfirmMgr.TRADE_RQMT tr
			inner join deleted d on d.ID = tr.ID
		where d.STATUS <> tr.STATUS
		and d.COMPLETED_DT is not null 
		and d.COMPLETED_DT = tr.COMPLETED_DT						
		
END



GO
EXEC sp_settriggerorder @triggername=N'[ConfirmMgr].[TG_TRDRQMT_BER_IU]', @order=N'First', @stmttype=N'INSERT'
GO
EXEC sp_settriggerorder @triggername=N'[ConfirmMgr].[TG_TRDRQMT_BER_IU]', @order=N'First', @stmttype=N'UPDATE'
GO
