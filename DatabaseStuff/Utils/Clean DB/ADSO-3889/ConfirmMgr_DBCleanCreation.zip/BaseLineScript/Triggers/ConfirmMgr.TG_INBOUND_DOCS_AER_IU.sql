SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE TRIGGER [ConfirmMgr].[TG_INBOUND_DOCS_AER_IU]
   ON  [ConfirmMgr].[INBOUND_DOCS] 
   AFTER INSERT, UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	
	DECLARE @payloads as AFFMSG.TABLE_CHANGE_SEND_MSG_TYPE;  
  
	insert into @payloads
	select distinct 
        '1' + '|' + 
        cast(id as varchar) +'|' + 
		FORMAT(RCVD_TS, 'dd-MMM-yyyy HH:mm:ss') + '| |'        
        doc_status_code		        
   from inserted;
   
  EXECUTE AFFMSG.TABLE_CHANGE_SEND_MSGS 'CONFIRMMGR.INBOUND_DOCS', @payloads

END

GO
