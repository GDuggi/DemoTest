SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE VIEW [ConfirmMgr].[V_DOCS_TO_VAULT]
as


select 
vd.id vaulted_docs_id,
vd.trade_rqmt_confirm_id vaulted_docs_trade_rqmt_confirm_id, 
vd.ASSOCIATED_DOCS_ID vaulted_docs_associated_docs_id,
vd.sent_flag vaulted_docs_sent_flag,
vd.metadata vaulted_docs_metadata,
vd.REQUEST_TIMESTAMP vaulted_docs_request_timestamp, 
vdb.ID vaulted_docs_blob_id, 
vdb.IMAGE_FILE_EXT vaulted_docs_blob_image_file_ext,
rdc.rqmt_code rqmt_doc_type_rqmt_code, 
rdc.sent_flag rqmt_doc_type_sent_flag,
rdc.doc_type_code rqmt_doc_type_doc_type_code,
t.TRD_SYS_CODE,
t.TRD_SYS_TICKET
from 
ConfirmMgr.vaulted_docs vd
join confirmMgr.Vaulted_docs_blob vdb
       on vd.ID = vdb.vaulted_docs_id
join ConfirmMgr.associated_docs ad
       on vd.associated_docs_id = ad.id
join ConfirmMgr.rqmt_doc_type rdc
       on ad.doc_type_code = rdc.rqmt_code
       and vd.sent_flag = rdc.sent_flag
join ConfirmMgr.trade_rqmt tr
       on ad.TRADE_RQMT_ID = tr.id
join ConfirmMgr.trade t
       on tr.TRADE_ID = t.id
       

where processed_flag = 'N'

union all

select 
vd.id vaulted_docs_id,
vd.trade_rqmt_confirm_id vaulted_docs_trade_rqmt_confirm_id, 
vd.ASSOCIATED_DOCS_ID vaulted_docs_associated_docs_id,
vd.sent_flag vaulted_docs_sent_flag,
vd.metadata vaulted_docs_metadata,
vd.REQUEST_TIMESTAMP vaulted_docs_request_timestamp, 
vdb.ID vaulted_docs_blob_id, 
vdb.IMAGE_FILE_EXT vaulted_docs_blob_image_file_ext,
rdc.rqmt_code rqmt_doc_type_rqmt_code, 
rdc.sent_flag rqmt_doc_type_sent_flag,
rdc.doc_type_code rqmt_doc_type_doc_type_code,
t.TRD_SYS_CODE,
t.TRD_SYS_TICKET

from 
ConfirmMgr.vaulted_docs vd
join confirmMgr.Vaulted_docs_blob vdb
       on vd.ID = vdb.vaulted_docs_id
join ConfirmMgr.TRADE_RQMT_CONFIRM trc
       on vd.trade_rqmt_confirm_id = trc.id
join ConfirmMgr.TRADE_RQMT tr
       on tr.id = trc.RQMT_ID
join ConfirmMgr.rqmt_doc_type rdc
       on tr.RQMT = rdc.rqmt_code
       and vd.sent_flag = rdc.sent_flag
join ConfirmMgr.trade t
       on tr.TRADE_ID = t.id
where processed_flag = 'N'

GO
GRANT SELECT ON [ConfirmMgr].[V_DOCS_TO_VAULT] TO [stanford_developers] AS [cm_admin]
GO
GRANT UPDATE ON [ConfirmMgr].[V_DOCS_TO_VAULT] TO [stanford_developers] AS [cm_admin]
GO
