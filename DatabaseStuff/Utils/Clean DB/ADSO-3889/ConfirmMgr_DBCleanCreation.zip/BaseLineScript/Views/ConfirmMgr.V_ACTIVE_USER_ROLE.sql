SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO




CREATE VIEW [ConfirmMgr].[V_ACTIVE_USER_ROLE]
AS 

	SELECT ur.USER_ID, ur.role_code, r.descr
    FROM ConfirmMgr.user_role ur
	INNER JOIN ConfirmMgr.ROLE r
	ON r.code = ur.role_code
    WHERE ur.active_flag = 'Y';




GO
GRANT SELECT ON [ConfirmMgr].[V_ACTIVE_USER_ROLE] TO [stanford_developers] AS [cm_admin]
GO
GRANT UPDATE ON [ConfirmMgr].[V_ACTIVE_USER_ROLE] TO [stanford_developers] AS [cm_admin]
GO
