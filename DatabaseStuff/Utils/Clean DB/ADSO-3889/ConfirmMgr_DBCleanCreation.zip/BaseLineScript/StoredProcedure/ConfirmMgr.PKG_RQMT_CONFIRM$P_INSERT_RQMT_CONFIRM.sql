SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_RQMT_CONFIRM$P_INSERT_RQMT_CONFIRM]
@p_id					int,
@p_rqmt_id				int,
@p_trade_id				int,
@p_template_name		varchar(100),
@p_confirm_cmt			varchar(255),
@p_fax_telex_ind		varchar(1),
@p_fax_telex_number		varchar(255),
@p_confirm_label		varchar(30),
@p_next_status_code		varchar(10)
AS
/******************************************************************************
*
* AUTHOR:		Stanford Developers - 09/03/2015
* MODIFIED:		Javier Montero - 09/03/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  
* DEPENDECIES:   
* CHANGES:		
*******************************************************************************/
BEGIN
	
		INSERT INTO ConfirmMgr.TRADE_RQMT_CONFIRM
		(
			ID,
			RQMT_ID,
			TRADE_ID,
			TEMPLATE_NAME,
			CONFIRM_CMT,
			FAX_TELEX_IND,
			FAX_TELEX_NUMBER,
			CONFIRM_LABEL,
			NEXT_STATUS_CODE
		)
		VALUES
		(
			@p_id,
			@p_rqmt_id,
			@p_trade_id,
			@p_template_name,
			@p_confirm_cmt,
			@p_fax_telex_ind,
			@p_fax_telex_number,
			@p_confirm_label,
			@p_next_status_code
		)
		
END

GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_RQMT_CONFIRM$P_INSERT_RQMT_CONFIRM] TO [stanford_developers] AS [cm_admin]
GO
