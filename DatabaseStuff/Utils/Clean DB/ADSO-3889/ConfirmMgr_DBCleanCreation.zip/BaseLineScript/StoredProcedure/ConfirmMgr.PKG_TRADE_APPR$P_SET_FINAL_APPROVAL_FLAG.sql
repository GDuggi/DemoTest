SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_APPR$P_SET_FINAL_APPROVAL_FLAG]
@p_trade_id           int,
@p_approval_flag      varchar(1),
@p_only_if_ready_flag varchar(1),
@p_appr_by_username   varchar(30),
@open_rqmt_ct		  INT OUTPUT
AS
BEGIN
SET NOCOUNT ON;
Declare

@sql			VARCHAR(400),
@sqlparam		VARCHAR(400),
@trade_appr_id	INT


	IF @p_only_if_ready_flag='Y' 
		BEGIN
		   SELECT 
		   @open_rqmt_ct = CASE WHEN rs.terminal_flag = 'N' THEN 1 ELSE 0 END --sum(decode(,'N',1,0))
		   FROM ConfirmMgr.trade_rqmt tr,
                ConfirmMgr.rqmt_status rs
			WHERE rs.rqmt_code = tr.rqmt
            and rs.status_code = tr.status
            and tr.trade_id = @p_trade_id;
		 END
      ELSE
	  BEGIN
         SET @open_rqmt_ct = 0;
      END

      IF @open_rqmt_ct = 0

	  BEGIN
		 INSERT INTO ConfirmMgr.TRADE_APPR
		 (id, trade_id, appr_flag, appr_timestamp_gmt, appr_by_username)
									 VALUES
									 (NEXT VALUE FOR ConfirmMgr.SEQ_TRADE_APPR --@trade_appr_id
                                      ,@p_trade_id
                                      ,@p_approval_flag
                                      ,GETDATE()
                                      ,@p_appr_by_username);

      END

      Return @open_rqmt_ct;
	
END

GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_APPR$P_SET_FINAL_APPROVAL_FLAG] TO [stanford_developers] AS [cm_admin]
GO
