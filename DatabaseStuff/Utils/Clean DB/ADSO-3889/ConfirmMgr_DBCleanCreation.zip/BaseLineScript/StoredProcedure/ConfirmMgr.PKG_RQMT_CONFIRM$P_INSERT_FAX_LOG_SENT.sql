SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_RQMT_CONFIRM$P_INSERT_FAX_LOG_SENT]
@p_trade_id			int,
@p_doc_type			varchar(3),
@p_sender			varchar(30),
@p_telex_code		varchar(5),
@p_telex_number		varchar(300),
@p_doc_ref_code		varchar(100)

AS
DECLARE 
@error_msg		nvarchar(max),
@error_id		int,
@error_sev		int,
@error_sta		int,
@error_line		int
BEGIN

	BEGIN TRY
		  INSERT INTO ConfirmMgr.FAX_LOG_SENT
			(
			ID,
			DOC_TYPE,
			TRADE_ID,
			SENDER,
			FAX_TELEX_CODE,
			FAX_TELEX_NUMBER,
			DOC_REF_CODE)
		  VALUES 
			  (NEXT VALUE FOR ConfirmMgr.SEQ_FAX_LOG_SENT,
			  @p_doc_type,
			  @p_trade_id,
			  @p_sender,
			  @p_telex_code,
			  @p_telex_number,
			  @p_doc_ref_code);
	END TRY
	BEGIN CATCH
		IF @@ERROR > 0
			SELECT @error_msg  = ERROR_PROCEDURE() + ' FAIL: ' + ERROR_MESSAGE(),
				   @error_id = ERROR_NUMBER(),
				   @error_sev = ERROR_SEVERITY(),
				   @error_sta = ERROR_STATE(),
				   @error_line = ERROR_LINE();
			RAISERROR(@error_msg, @error_id, @error_sev, @error_sta, @error_line) WITH LOG
	END CATCH

END

GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_RQMT_CONFIRM$P_INSERT_FAX_LOG_SENT] TO [stanford_developers] AS [cm_admin]
GO
