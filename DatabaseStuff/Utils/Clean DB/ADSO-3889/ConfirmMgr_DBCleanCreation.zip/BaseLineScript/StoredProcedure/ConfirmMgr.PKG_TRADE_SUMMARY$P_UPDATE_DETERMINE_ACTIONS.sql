SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_SUMMARY$P_UPDATE_DETERMINE_ACTIONS]
@p_trade_id				int,
@p_ops_det_act_flag		varchar(1)
AS
/******************************************************************************
*
* AUTHOR:		Stanford Developers - 09/03/2015
* MODIFIED:		Javier Montero - 09/03/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  
* DEPENDECIES:   
* CHANGES:		
*******************************************************************************/
DECLARE
@l_ready_for_final_approval varchar(1),
@error_msg		nvarchar(max),
@error_id		int,
@error_sev		int,
@error_sta		int,
@error_line		int

BEGIN
	BEGIN TRY
      IF (@p_ops_det_act_flag = 'E') OR (@p_ops_det_act_flag = 'R')
	  
         UPDATE ConfirmMgr.TRADE_SUMMARY
            SET 
               OPS_DET_ACT_FLAG = @p_ops_det_act_flag, 
               READY_FOR_FINAL_APPROVAL_FLAG = 'N'
         WHERE TRADE_SUMMARY.TRADE_ID = @p_trade_id
      ELSE 
         IF (@p_ops_det_act_flag = 'N')
            BEGIN
               SELECT @l_ready_for_final_approval = 
                  CASE fci.non_terminal_ct
                     WHEN 0 THEN 'Y'
                     ELSE 'N'
				  END
               FROM 
                  ( SELECT tr.TRADE_ID, sum(
                        CASE rs.TERMINAL_FLAG
                           WHEN 'N' THEN 1
                           ELSE 0
                        END) AS non_terminal_ct
                     FROM ConfirmMgr.TRADE_RQMT  AS tr, ConfirmMgr.RQMT_STATUS  AS rs
                     WHERE 
                        tr.TRADE_ID = @p_trade_id AND 
                        tr.RQMT = rs.RQMT_CODE AND 
                        tr.STATUS = rs.STATUS_CODE
                     GROUP BY tr.TRADE_ID
                  )  AS fci
				

               UPDATE ConfirmMgr.TRADE_SUMMARY
                  SET 
                     OPS_DET_ACT_FLAG = @p_ops_det_act_flag, 
                     READY_FOR_FINAL_APPROVAL_FLAG = @l_ready_for_final_approval
                  WHERE TRADE_SUMMARY.TRADE_ID = @p_trade_id

            END
         ELSE 
            UPDATE ConfirmMgr.TRADE_SUMMARY
            SET OPS_DET_ACT_FLAG = @p_ops_det_act_flag
            WHERE TRADE_SUMMARY.TRADE_ID = @p_trade_id
		END TRY
		BEGIN CATCH
				IF @@ERROR > 0
				SELECT @error_msg  = 'PROCEDURE PKG_TRADE_SUMMARY$P_UPDATE_DETERMINE_ACTIONS FAIL: ' + ERROR_MESSAGE(),
				   @error_id = ERROR_NUMBER(),
				   @error_sev = ERROR_SEVERITY(),
				   @error_sta = ERROR_STATE(),
				   @error_line = ERROR_LINE();
				RAISERROR(@error_msg, @error_id, @error_sev, @error_sta, @error_line) -- WITH LOG
		END CATCH

END


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_SUMMARY$P_UPDATE_DETERMINE_ACTIONS] TO [stanford_developers] AS [cm_admin]
GO
