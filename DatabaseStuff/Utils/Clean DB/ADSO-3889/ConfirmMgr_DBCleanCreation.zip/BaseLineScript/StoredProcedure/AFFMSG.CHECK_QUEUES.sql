SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [AFFMSG].[CHECK_QUEUES]
-- Return QUEUE status, if all is working then e.state = 'CO'
as begin
  select N'//AFF/MSG/TABLE_CHANGE_SERVICE_SEND' as queue_name, e.state, e.state_desc
    from service_broker_settings s,
         sys.conversation_endpoints e
   where s.source = N'//AFF/MSG/TABLE_CHANGE_SERVICE_SEND'
     and s.destination = N'//AFF/MSG/TABLE_CHANGE_SERVICE_RECEIVE'
     and s.contract = N'DEFAULT' 
     and s.destination collate database_default = e.far_service collate database_default
     and s.dialog_handle = e.conversation_handle;   
end;
GO
