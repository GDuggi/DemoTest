SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [ConfirmMgr].[PKG_RQMT_CONFIRM$P_UPDATE_FAX_GATEWAY_STATUS]
@p_trade_id					int,
@p_trade_rqmt_id			int,
@p_trade_rqmt_confirm_id	int,
@p_status					varchar(10),
@p_addr						varchar(1000),
@p_label					varchar(max),
@p_sender					varchar(255),
@p_fax_telex_ind			varchar(1),
@p_cmt						varchar(255)
AS
/******************************************************************************
*
* AUTHOR:		Stanford Developers - 09/03/2015
* MODIFIED:		Javier Montero - 09/03/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  
* DEPENDECIES:   
* CHANGES:		
*******************************************************************************/
DECLARE
@l_rqmt_status	varchar(10) = NULL, 
@l_conf_status	varchar(10) = NULL,
@error_msg		nvarchar(max),
@error_id		int,
@error_sev		int,
@error_sta		int,
@error_line		int 
BEGIN

	  SET @l_conf_status = NULL
	  SET @l_rqmt_status = NULL

	  BEGIN TRY
			IF (@p_status = 'S')
			 SET @l_rqmt_status = 'SENT'
		  ELSE 
			 IF (@p_status = 'F')
				SET @l_rqmt_status = 'FAIL'

		  IF (@l_conf_status IS NULL)
			 BEGIN
				UPDATE trc
				SET 
				   trc.XMIT_STATUS_IND = ISNULL(trc.XMIT_STATUS_IND, '') + ISNULL(
					  CASE isnull(trc.XMIT_STATUS_IND, NULL)
						 WHEN NULL THEN NULL
						 ELSE ';'
					  END, '') + ISNULL(@p_status, ''), 
				   trc.XMIT_ADDR = ISNULL(trc.XMIT_ADDR, '') + ISNULL(
					  CASE isnull(trc.XMIT_ADDR, NULL)
						 WHEN NULL THEN NULL
						 ELSE ';'
					  END, '') + ISNULL(@p_status, '') + ':' + ISNULL(@p_addr, ''), 
				   trc.XMIT_TIMESTAMP_GMT = sysdatetime()
				FROM ConfirmMgr.TRADE_RQMT_CONFIRM trc
				WHERE trc.ID = @p_trade_rqmt_confirm_id
			 END			 
		  ELSE
			BEGIN
				UPDATE trc 
				SET trc.NEXT_STATUS_CODE = @l_conf_status, 
				   trc.XMIT_STATUS_IND = ISNULL(trc.XMIT_STATUS_IND, '') + ISNULL(
					  CASE isnull(trc.XMIT_STATUS_IND, NULL)
						 WHEN NULL THEN NULL
						 ELSE ';'
					  END, '') + ISNULL(@p_status, ''), 
				   trc.XMIT_ADDR = ISNULL(trc.XMIT_ADDR, '') + ISNULL(
					  CASE isnull(trc.XMIT_ADDR, NULL)
						 WHEN NULL THEN NULL
						 ELSE ';'
					  END, '') + ISNULL(@p_status, '') + ':' + ISNULL(@p_addr, ''), 
				   trc.XMIT_TIMESTAMP_GMT = sysdatetime()
				FROM ConfirmMgr.TRADE_RQMT_CONFIRM trc
				WHERE trc.ID = @p_trade_rqmt_confirm_id
			END 
			 
		  /*Inserting values in Fax_Log_Status table via SP*/	
		  EXECUTE ConfirmMGr.PKG_RQMT_CONFIRM$p_insert_fax_log_status
			 @p_trade_id = @p_trade_id, 
			 @p_trade_rqmt_confirm_id = @p_trade_rqmt_confirm_id, 
			 @p_sender = @p_sender, 
			 @p_telex_ind = @p_fax_telex_ind, 
			 @p_telex_number = @p_addr, 
			 @p_cmt = @p_cmt, 
			 @p_reply_status = @p_status

		  IF (@l_rqmt_status IS NOT NULL)
			 BEGIN
				 UPDATE tr
					SET tr.STATUS = @l_rqmt_status
				 FROM ConfirmMgr.TRADE_RQMT  tr
				 WHERE tr.ID = @p_trade_rqmt_id AND tr.STATUS IN 
					(
					   SELECT rs.STATUS_CODE
					   FROM ConfirmMgr.RQMT_STATUS  AS rs
					   WHERE rs.TERMINAL_FLAG = 'N' AND rs.RQMT_CODE = tr.RQMT
					)
			END
	  END TRY
	  BEGIN CATCH
		IF @@ERROR > 0
			SELECT @error_msg  = ERROR_PROCEDURE() + ' FAIL: ' + ERROR_MESSAGE(),
				   @error_id = ERROR_NUMBER(),
				   @error_sev = ERROR_SEVERITY(),
				   @error_sta = ERROR_STATE(),
				   @error_line = ERROR_LINE();
			RAISERROR(@error_msg, @error_id, @error_sev, @error_sta, @error_line) WITH LOG
	  END CATCH
      


END -- END PROCEDURE


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_RQMT_CONFIRM$P_UPDATE_FAX_GATEWAY_STATUS] TO [stanford_developers] AS [cm_admin]
GO
