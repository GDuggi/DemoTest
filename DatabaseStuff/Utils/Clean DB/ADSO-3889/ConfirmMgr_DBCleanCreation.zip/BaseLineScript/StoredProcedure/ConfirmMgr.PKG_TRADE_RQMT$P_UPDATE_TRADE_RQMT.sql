SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_RQMT$P_UPDATE_TRADE_RQMT]
@p_rqmt_id			int,   --THIS VARIABLE IS FOR VALIDATED AND VERIFIED IF EXISTS IN THE TABLE TRADE_RQMT
@p_completion_date	date,  --COMPLETATION DATE
@p_second_chk		varchar(1),
@p_status			varchar(10),
@p_reference		varchar(30),
@p_cmt				varchar(500)
AS
/******************************************************************************
*
* AUTHOR:		Stanford Developers - 09/02/2015
* MODIFIED:		Javier Montero - 09/02/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  
* DEPENDECIES:   
* CHANGES:		
*******************************************************************************/
DECLARE 
@error_msg		nvarchar(max),
@error_id		int,
@error_sev		int,
@error_sta		int,
@error_line		int
BEGIN
	BEGIN TRY
		IF (@p_rqmt_id) IS NOT NULL  
		BEGIN
		  UPDATE trqmt
		  set trqmt.STATUS = @p_status,
		  trqmt.COMPLETED_DT = @p_completion_date,
		  trqmt.REFERENCE = @p_reference,
		  trqmt.CMT = @p_cmt
		  FROM ConfirmMgr.TRADE_RQMT trqmt
		  WHERE trqmt.ID = @p_rqmt_id
		END
	END TRY
	BEGIN CATCH
		IF @@ERROR > 0
			SELECT @error_msg  = 'PROCEDURE PKG_TRADE_RQMT$P_UPDATE_TRADE_RQMT FAIL: ' + ERROR_MESSAGE(),
				   @error_id = ERROR_NUMBER(),
				   @error_sev = ERROR_SEVERITY(),
				   @error_sta = ERROR_STATE(),
				   @error_line = ERROR_LINE();
			RAISERROR(@error_msg, @error_id, @error_sev, @error_sta, @error_line) WITH LOG
	END CATCH

END;


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_RQMT$P_UPDATE_TRADE_RQMT] TO [stanford_developers] AS [cm_admin]
GO
