SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_SUMMARY$P_UPDATE_TRADE_SUMMARY]
@p_trade_id         int,
@p_fnlapp_flag      varchar(1),
@p_opsdetact_flag   varchar(1),
@p_openrqmts_flag   varchar(1),
@p_cmt              varchar(255),
@forceCmtToNullFlag varchar(1) = 'N'
AS
/******************************************************************************
*
* AUTHOR:		Stanford Developers - 09/03/2015
* MODIFIED:		Javier Montero - 09/03/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  
* DEPENDECIES:   
* CHANGES:		
*******************************************************************************/
DECLARE 
@error_msg		nvarchar(max),
@error_id		int,
@error_sev		int,
@error_sta		int,
@error_line		int
BEGIN
		BEGIN TRY
			IF(@p_trade_id) IS NOT NULL
			BEGIN
					Update ts
					SET FINAL_APPROVAL_FLAG = 
						CASE
								WHEN upper(@p_fnlapp_flag) IN ('Y','N') THEN @p_fnlapp_flag
								ELSE ts.FINAL_APPROVAL_FLAG
							END,
					OPS_DET_ACT_FLAG = 
						CASE 
								WHEN upper(@p_opsdetact_flag) IN ('Y','N') THEN @p_opsdetact_flag
								ELSE ts.OPS_DET_ACT_FLAG
							END, 
					OPEN_RQMTS_FLAG = 
						CASE 
								WHEN upper(@p_openrqmts_flag) IN ('Y','N') THEN @p_openrqmts_flag
								ELSE ts.OPEN_RQMTS_FLAG
							END, 
					CMT = 
						CASE 
								WHEN upper(@forceCmtToNullFlag) = 'Y' THEN NULL
								ELSE ISNULL(@p_cmt, ts.CMT)
							END
					FROM ConfirmMgr.TRADE_SUMMARY ts
					WHERE trade_id = @p_trade_id;
			END
		END TRY
		BEGIN CATCH
				IF @@ERROR > 0
				SELECT @error_msg  = 'PROCEDURE PKG_TRADE_SUMMARY$P_UPDATE_TRADE_SUMMARY FAIL: ' + ERROR_MESSAGE(),
				   @error_id = ERROR_NUMBER(),
				   @error_sev = ERROR_SEVERITY(),
				   @error_sta = ERROR_STATE(),
				   @error_line = ERROR_LINE();
			RAISERROR(@error_msg, @error_id, @error_sev, @error_sta, @error_line) WITH LOG
		END CATCH
END


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_SUMMARY$P_UPDATE_TRADE_SUMMARY] TO [stanford_developers] AS [cm_admin]
GO
