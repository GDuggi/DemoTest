SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create procedure [AFFMSG].[TABLE_CHANGE_RECEIVE_MSG]
  @wait_millis int = -1,     -- (-1)=FOREVER, 0=NOWAIT, in millis  
  @batch_size int = 1000     -- # of rows to return
as begin
  set nocount on;
 
  declare @receive TABLE_CHANGE_RESULT_TYPE;
   
  waitfor (  
    receive top(@batch_size) 
            message_type_name, 
            cast(message_body as varchar(4000)) as message_body, 
            message_sequence_number, 
            conversation_handle
        from TABLE_CHANGE_QUEUE_RECEIVE into @receive
  ), timeout @wait_millis;
  
  -- remove duplicates
  select distinct message_type_name, message_body
    from @receive;
end;
GO
