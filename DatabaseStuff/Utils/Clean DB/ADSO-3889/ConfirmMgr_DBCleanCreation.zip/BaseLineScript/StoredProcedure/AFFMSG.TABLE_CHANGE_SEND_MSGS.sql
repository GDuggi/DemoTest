SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [AFFMSG].[TABLE_CHANGE_SEND_MSGS]
  @key         sysname,
  @payloads	   [AFFMSG].[TABLE_CHANGE_SEND_MSG_TYPE] READONLY
AS
  set nocount on;

  declare @currentPayload varchar(4000);    
  declare i_cursor cursor for select distinct payload from @payloads;
  open i_cursor;
  fetch next from i_cursor into @currentPayload;
  
  while @@FETCH_STATUS = 0 begin
    EXECUTE AFFMSG.TABLE_CHANGE_SEND_MSG @key, @currentPayload;     
    fetch next from i_cursor into @currentPayload;
  end
  close i_cursor;
  deallocate i_cursor;

  



GO
