SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_INBOUND_EXT$P_UPDATE_USER_FLAG]

   @p_inbound_doc_id int,
   @p_inbound_user varchar(max),
   @p_flag_type varchar(max),
   @p_comment varchar(max),
   @p_update_delete_ind varchar(max)
AS 
   BEGIN

      IF @p_update_delete_ind = 'D'
         DELETE ConfirmMgr.INBOUND_DOC_USER_FLAG
         WHERE 
            INBOUND_DOC_USER_FLAG.INBOUND_DOC_ID = @p_inbound_doc_id AND 
            INBOUND_DOC_USER_FLAG.INBOUND_USER = @p_inbound_user AND 
            INBOUND_DOC_USER_FLAG.FLAG_TYPE = @p_flag_type
      ELSE 

	MERGE INTO ConfirmMgr.INBOUND_DOC_USER_FLAG AS Target
	USING (select @p_inbound_doc_id as inbound_doc_id, @p_inbound_user as inbound_user, @p_flag_type as flag_type) AS source
	ON (target.inbound_doc_id = source.inbound_doc_id  AND target.inbound_user = source.inbound_user AND target.flag_type = source.flag_type)
	WHEN MATCHED THEN
	    UPDATE SET comments = @p_comment
	WHEN NOT MATCHED BY Target THEN
	    INSERT (inbound_doc_id, inbound_user, flag_type, comments) 
	    VALUES (@p_inbound_doc_id, @p_inbound_user, @p_flag_type, @p_comment);

   END

GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_INBOUND_EXT$P_UPDATE_USER_FLAG] TO [stanford_developers] AS [cm_admin]
GO
