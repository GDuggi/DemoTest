SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_RQMT$P_UPDATE_TRADE_CONFIRM_CREATOR]
@p_rqmt_confirm_id		int,
@p_user					varchar(200)
AS
/******************************************************************************
*
* AUTHOR:		Stanford Developers - 09/02/2015
* MODIFIED:		Javier Montero - 09/02/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  
* DEPENDECIES:   
* CHANGES:		
*******************************************************************************/
BEGIN
	
		MERGE INTO ConfirmMgr.TRADE_RQMT_CONFIRM_CREATOR AS a
		USING (SELECT @p_rqmt_confirm_id AS id) AS b
			  ON (a.rqmt_confirm_id= b.id)
		WHEN MATCHED THEN
			  UPDATE SET user_id = @p_user
		WHEN  NOT MATCHED BY TARGET THEN
			  INSERT(rqmt_confirm_id, user_id)
			  VALUES(@p_rqmt_confirm_id,@p_user);  
    

END;

GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_RQMT$P_UPDATE_TRADE_CONFIRM_CREATOR] TO [stanford_developers] AS [cm_admin]
GO
