SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_RQMT$P_CANCEL_ALL_RQMTS]
@p_trade_id int,
@p_cxl_cmt varchar(max)
AS 
BEGIN
DECLARE
@v_rqmts_id			int, 
@v_rqmts_rqmt		varchar(10), 
@v_rqmts_status		varchar(max),
@v_returned_value	varchar(1) = 'N'  --This variable is used to retrieve the flag status from Function then is Evaluated

      DECLARE c_rqmts CURSOR LOCAL FORWARD_ONLY FOR 
            SELECT tr.ID, tr.RQMT, tr.STATUS
            FROM ConfirmMgr.TRADE_RQMT  AS tr
            WHERE tr.TRADE_ID = @p_trade_id

      OPEN c_rqmts

      WHILE 1 = 1
      
         BEGIN

            FETCH c_rqmts
                INTO @v_rqmts_id, @v_rqmts_rqmt, @v_rqmts_status

            IF @@FETCH_STATUS = -1
               BREAK

			/*RETRIEVING FLAG VALUE FROM FUNCTION*/
			SELECT @v_returned_value = ConfirmMgr.PKG_TRADE_RQMT$F_IS_INITIAL_STATUS(@v_rqmts_rqmt, @v_rqmts_status) 
            /*BY DEFAULT @V_RETURN_VALUE IS N */
			IF @v_returned_value = 'Y' 
			BEGIN 
               UPDATE ConfirmMgr.TRADE_RQMT
                  SET STATUS = 'CXL', CMT = @p_cxl_cmt
               WHERE TRADE_RQMT.ID = @v_rqmts_id AND TRADE_RQMT.STATUS <> 'CXL'
			 END
         END

      CLOSE c_rqmts
      DEALLOCATE c_rqmts

END


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_RQMT$P_CANCEL_ALL_RQMTS] TO [stanford_developers] AS [cm_admin]
GO
