SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [AFFMSG].[CLEANUP_QUEUE_MESSAGES]
   @cleanup_flag varchar(1) = 'Y'
AS
BEGIN
    BEGIN TRY
        -- create a memory table. I dont prefer cursors usually
        DECLARE @t TABLE( AutoID INT IDENTITY, ConversationHandle UNIQUEIDENTIFIER)
        
        -- insert the handles of all open conversations to the 
        -- memory table
        INSERT INTO @t (ConversationHandle)
          SELECT [conversation_handle] FROM sys.conversation_endpoints
            
        -- local variables
        DECLARE @cnt INT, @max INT, @handle UNIQUEIDENTIFIER
        SELECT @cnt = 1, @max = COUNT(*) FROM @t
        
        -- run a loop for each row in the memory table
        WHILE @cnt <= @max BEGIN
            -- read the conversation_handle
            SELECT @handle = ConversationHandle FROM @t WHERE AutoID = @cnt
            
            -- end conversation
            print 'closing conversation: ' + cast(@handle as varchar(50))
            begin try
              if @cleanup_flag = 'Y' end conversation @handle with cleanup            
              else end conversation @handle            
            end try
            begin catch
              print error_message()
            end catch
            
            -- increment counter
            SELECT @cnt = @cnt + 1
        END
        
    END TRY
    BEGIN CATCH
        PRINT ERROR_MESSAGE()
    END CATCH
END
GO
