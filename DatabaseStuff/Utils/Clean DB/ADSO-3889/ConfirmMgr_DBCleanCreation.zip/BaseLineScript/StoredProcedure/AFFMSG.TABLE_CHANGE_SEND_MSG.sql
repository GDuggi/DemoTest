SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [AFFMSG].[TABLE_CHANGE_SEND_MSG]
  @key         sysname,
  @payload     varchar(4000)
AS
  set nocount on;
  declare @dialog_handle uniqueidentifier;
  declare @source nvarchar(256);
  declare @destination  nvarchar(256);
  declare @contract   nvarchar(256);
  
  set @source = N'//AFF/MSG/TABLE_CHANGE_SERVICE_SEND';
  set @destination = N'//AFF/MSG/TABLE_CHANGE_SERVICE_RECEIVE';
  set @contract = N'DEFAULT';
  
  select @dialog_handle = s.dialog_handle 
    from service_broker_settings s,
         sys.conversation_endpoints e
   where s.source = @source
     and s.destination = @destination
     and s.contract = @contract
     and s.destination = e.far_service collate SQL_Latin1_General_CP1_CI_AS
     and s.dialog_handle = e.conversation_handle;  
  
  if @dialog_handle is null
  begin
    print 'TABLE_CHANGE_SEND_MSG, creating conversation';
    begin dialog conversation @dialog_handle
	   from service    [//AFF/MSG/TABLE_CHANGE_SERVICE_SEND]
	     to service    @destination
     with encryption = off;
        
    update service_broker_settings
       set dialog_handle = @dialog_handle
     where source = @source and destination = @destination and contract = @contract;
   
    if @@rowcount = 0 
      insert into service_broker_settings ( source, destination, contract, dialog_handle )
        values ( @source, @destination, @contract, @dialog_handle );
            
  end
    
  print 'TABLE_CHANGE_SEND_MSG, Using conversation: ' + cast(@dialog_handle as varchar(50));
       
  declare @msg varchar(max);
  set @msg = @key + '|' + @payload;

  -- Send our data to be audited
  send on conversation @dialog_handle (@msg);

  print 'TABLE_CHANGE_SEND_MSG, sent: ' + @msg
GO
