SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ConfirmMgr].[PKG_TRADE_SUMMARY$P_UPDATE_FINAL_APPROVAL]
@p_trade_id			int,
@p_fnlapp_status	varchar(1)
AS
/**********************************************************************************
*
* AUTHOR:		Javier Montero - 09/03/2015
* MODIFIED:		
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  This SP updates the final approval flag on the TRADE_SUMMARY TABLE
* DEPENDECIES:   
* CHANGES:		
***********************************************************************************/
DECLARE 
@error_msg		nvarchar(max),
@error_id		int,
@error_sev		int,
@error_sta		int,
@error_line		int

BEGIN
	BEGIN TRY
		IF(@p_trade_id) IS NOT NULL
		BEGIN
			UPDATE ts			
			SET ts.FINAL_APPROVAL_FLAG = @p_fnlapp_status
			FROM ConfirmMgr.TRADE_SUMMARY ts
			WHERE ts.TRADE_ID = @p_trade_id;
	    END
	END TRY
	BEGIN CATCH
	IF @@ERROR > 0
			SELECT @error_msg  = 'PROCEDURE PKG_TRADE_SUMMARY$P_UPDATE_FINAL_APPROVAL FAIL: ' + ERROR_MESSAGE(),
				   @error_id = ERROR_NUMBER(),
				   @error_sev = ERROR_SEVERITY(),
				   @error_sta = ERROR_STATE(),
				   @error_line = ERROR_LINE();
			RAISERROR(@error_msg, @error_id, @error_sev, @error_sta, @error_line) WITH LOG
	END CATCH
END


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_SUMMARY$P_UPDATE_FINAL_APPROVAL] TO [stanford_developers] AS [cm_admin]
GO
