<#

.NAME
	CREATE_SCHEMA
.SYNOPSIS
	SCRIPT DEVELOPED TO CREATE DATABASE SCHEMAS 

.DESCRIPTION
	This script creates a DB SCHEMAS objects 
	
.PARAMETERS 
	$dbusername   :  DatabaseUser with credentials to logon as sysadmin
	$dbuspassw    :  Password of Database User
	$srvinstance  :  SQL Server Instance to work
	$db_name      :  SQL Server Database Name to Script
	
	
.INPUTS
	
.OUTPUTS
	SchemaName.ObjectName.sql
	Error Log Results error.log
	
.EXAMPLE
 Ps c:\> .\CREATE_SCHEMA.ps1

.NOTES
	Author        :	Javier Montero  - 11/25/2015
    Version       :	1.0	
	Compatibility :	PS 2.0 or Higher
	SQL Ver       :	SQL Server 2008R2 or Higher
	TO GET HELP OR ANY NOTE HERE TYPE GET-HELP .\CREATE_SCHEMA.ps1
	
#>

param(
	
	[Parameter(Position=0, Mandatory=$true)]
	[string]$srvinstance,
	[Parameter(Position=1, Mandatory=$true)]
	[string]$dbuser,
	[Parameter(Position=2, Mandatory=$true)]
	[string]$dbuspassw,
	[Parameter(Position=3, Mandatory=$true)]
	[string]$dbname

)

$server         = $srvinstance
$user           = $dbuser
$passw          = $dbuspassw
$db_name        = $dbname
$scriptspath    = Split-Path -Parent $MyInvocation.MyCommand.Definition

# trap errors
$errors = $scriptspath+"\errors.log"
trap
{
  "______________________" | out-file $errors -append;
  "ERROR SCRIPTING " | out-file $errors -append;
  get-date | out-file $errors -append;
  "ERROR: " + $_ | out-file $errors -append;
  "`$server = $server" | out-file $errors -append;
  "`$database = $db_name" | out-file $errors -append;
  #"`$scripts = $scripts" | out-file $errors -append;
  throw "ERROR!!!!: See $errors"
}

[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null #<-- Powershell V 2.0 Higher

$srv 		= New-Object "Microsoft.SqlServer.Management.SMO.Server" $server

#Login credentials
$srv.ConnectionContext.LoginSecure = $false;
#$credential = Get-Credential
$SqlUPwd = ConvertTo-SecureString $passw -AsPlainText -Force; #Converting Password text to Secury credentials
$srv.ConnectionContext.set_Login($user);
$srv.ConnectionContext.set_SecurePassword($SqlUPwd);

Write-Host $scriptspath
$pathfile = $scriptspath

function CREATE_SCHEMA($serverobj, $dbobj, $userobj, $passobj, $fileobj, $objname)
{
	
		try{
				Write-Host "CREATING SCHEMA " + $objname	
				Import-module SQLPS -DisableNameChecking
				Invoke-Sqlcmd -InputFile $fileobj `
				-ServerInstance $serverobj `
				-Database $dbobj `
				-Username $userobj `
				-Password $passobj `
				| Out-File -filepath $scriptspath\"Schema\logs\"$objname".log"	
			}	    
		catch
			{
				Write-Host($_)
			}
	
}


if($pathfile -ne $null)
{
	$pathlist = Get-Item -Path $pathfile
	$fspath = $pathfile+"\Schema"

		if(Test-Path $fspath -PathType Container)
		{
			
			if(Test-Path -Path $scriptspath\"Schema\logs" -PathType Container)
			{
				Write-Host "Removing Previous Log Files If Exists"	
				Remove-Item $scriptspath\"Schema\logs" -Include .log
				Set-Location $fspath
				Write-Host "If you need help about the parameters, Please Use the cmdlet Get-Help .\FileStreamAccess_Validation.ps1"
				$list = Get-ChildItem $fspath | Where-Object{$_.Extension -eq ".sql"}
				Write-Host "CREATING SCHEMAS ON CONFIRMATIONS MANAGER DATABASE...."
				Foreach($script in $list)
				{
					if($script -ne $null)
					{
						$text = Get-Content $script
						[string]$value = "$($fspath)\$script"		
						Write-Host $value
						CREATE_SCHEMA $server $db_name $user $passw $value $script
						Set-Location -Path .. -PassThru
					
					}	
					else
					{
						Write-Host ".SQL Script Don't exists please validate"
					}
				}
			}
			else
			{
				Write-Host "Creating Logs Folder"	
				New-Item $scriptspath\"Schema\logs" -ItemType directory
				Set-Location $fspath
				Write-Host "If you need help about the parameters, Please Use the cmdlet Get-Help .\FileStreamAccess_Validation.ps1"
				$list = Get-ChildItem $fspath | Where-Object{$_.Extension -eq ".sql"}
				Write-Host "CREATING SCHEMAS ON CONFIRMATIONS MANAGER DATABASE...."
				Foreach($script in $list)
				{
					if($script -ne $null)
					{
						$text = Get-Content $script
						[string]$value = "$($fspath)\$script"		
						Write-Host $value
						CREATE_SCHEMA $server $db_name $user $passw $value $script
						Set-Location -Path .. -PassThru
					
					}	
					else
					{
						Write-Host ".SQL Script Don't exists please validate"
					}
				}
			}
			
			
		}
	else
	{
		Write-Host "Failed"
	}
	

	
}