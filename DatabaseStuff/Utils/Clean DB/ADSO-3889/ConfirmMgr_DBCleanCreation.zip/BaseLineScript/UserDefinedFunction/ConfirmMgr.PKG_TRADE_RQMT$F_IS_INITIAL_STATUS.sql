SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [ConfirmMgr].[PKG_TRADE_RQMT$F_IS_INITIAL_STATUS]
(
   @p_rqmt_code varchar(max),
   @p_current_status varchar(max)
)
RETURNS VARCHAR(1)

AS 
/********************************************************************************************************
*
* AUTHOR:		Stanford Developers - 09/03/2015
* MODIFIED:		Javier Montero - 10/26/2015
* DB:			SQL SERVER 2012 OR HIGHER
* VERSION:		1.0
* DESCRIPTION:  USE TO RETURN A VARCHAR VALUE TO STORED PROCEDURE PKG_TRADE_RQMT$P_CANCEL_ALL_RQMTS
* DEPENDECIES:   
* CHANGES:		
**********************************************************************************************************/
BEGIN
DECLARE
@v_initial_status varchar(10),    --Initial status value
@v_is_initial_status_flag varchar(1),
@return_value_argument varchar(1)      --Returned value

      SET @v_is_initial_status_flag = 'N'

      SELECT @v_initial_status = RQMT.INITIAL_STATUS
      FROM ConfirmMgr.RQMT
      WHERE RQMT.CODE = @p_rqmt_code

      IF @v_initial_status = @p_current_status
         BEGIN
			SET @v_is_initial_status_flag = 'Y'
			SET @return_value_argument = @v_is_initial_status_flag
		 END

      RETURN @return_value_argument

   END


GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_RQMT$F_IS_INITIAL_STATUS] TO [stanford_developers] AS [cm_admin]
GO
