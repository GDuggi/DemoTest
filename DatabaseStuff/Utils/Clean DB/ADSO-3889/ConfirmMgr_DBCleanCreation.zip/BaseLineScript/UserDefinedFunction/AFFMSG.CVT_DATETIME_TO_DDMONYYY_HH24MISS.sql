SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
create function [AFFMSG].[CVT_DATETIME_TO_DDMONYYY_HH24MISS](@dt datetime)  returns varchar(11) as 
begin
   return substring( CONVERT( varchar, @dt, 106 ), 8,4 ) + '-' +
        upper(substring( CONVERT( varchar, @dt, 106 ), 4, 3 )) + '-' +
        substring( CONVERT( varchar, @dt, 106 ), 1,2 ) + ' ' +        
        CONVERT( varchar, @dt, 8 ); 
end;
GO
