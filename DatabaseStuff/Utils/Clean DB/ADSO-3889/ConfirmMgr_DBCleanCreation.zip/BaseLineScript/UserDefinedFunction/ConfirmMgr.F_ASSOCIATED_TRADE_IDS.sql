SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [ConfirmMgr].[F_ASSOCIATED_TRADE_IDS]
(
	@inbound_doc_id INT
)
RETURNs varchar(max)
AS
BEGIN
DECLARE 		 
@lvar				 varchar(max),
@return_value        varchar(max),
@csr$ID				 float(53), 
@csr$caller_ref		 varchar(max), 
@csr$sent_to		 varchar(max), 
@csr$rcvd_ts		 datetime2(0), 
@csr$file_name		 varchar(max), 
@csr$sender			 varchar(max), 
@csr$cmt			 varchar(max), 
@csr$doc_status_code varchar(max),
@csr$trade_id		 float(53)


	

	    DECLARE cur_datos CURSOR FOR
		SELECT a.ID, caller_ref, sent_to, rcvd_ts, a.file_name, sender,
          cmt, a.doc_status_code, trade_id
		FROM ConfirmMgr.inbound_docs a,
          ConfirmMgr.associated_docs b
		WHERE a.ID = b.inbound_docs_id
	      and b.doc_status_code <> 'DISCARDED'
          and b.doc_status_code <> 'UNASSOCIATED'
          and a.id = @inbound_doc_id;

		OPEN cur_datos;

		WHILE 1=1
			BEGIN
				FETCH cur_datos INTO
					@csr$ID, 
					@csr$caller_ref, 
					@csr$sent_to, 
					@csr$rcvd_ts, 
					@csr$file_name, 
					@csr$sender, 
					@csr$cmt, 
					@csr$doc_status_code,
					@csr$trade_id	
				
				IF @@FETCH_STATUS = -1
					
					BREAK
					
		       SET @lvar = ISNULL(@lvar, '') + ',' + ISNULL(CAST(@csr$trade_id AS nvarchar(max)), '')
			   
			END

			CLOSE cur_datos
			
			DEALLOCATE cur_datos
			

			SET @return_value = SUBSTRING(@lvar,0,2)
			RETURN @return_value

	
	
		
END
GO
GRANT EXECUTE ON [ConfirmMgr].[F_ASSOCIATED_TRADE_IDS] TO [AFFINF] AS [cm_admin]
GO
GRANT EXECUTE ON [ConfirmMgr].[F_ASSOCIATED_TRADE_IDS] TO [rnell] AS [cm_admin]
GO
GRANT EXECUTE ON [ConfirmMgr].[F_ASSOCIATED_TRADE_IDS] TO [stanford_developers] AS [cm_admin]
GO
