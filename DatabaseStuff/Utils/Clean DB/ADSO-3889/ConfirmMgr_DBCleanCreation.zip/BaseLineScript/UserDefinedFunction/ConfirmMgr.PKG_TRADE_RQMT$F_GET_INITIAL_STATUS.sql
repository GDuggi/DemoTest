SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE FUNCTION [ConfirmMgr].[PKG_TRADE_RQMT$F_GET_INITIAL_STATUS] 
(@p_rqmt_code VARCHAR(10))
RETURNS VARCHAR(10)
AS
BEGIN
	DECLARE @ret VARCHAR(10);

	SELECT @ret = r.initial_status
	FROM ConfirmMgr.RQMT r
	WHERE r.code = @p_rqmt_code
		AND r.active_flag = 'Y';

	RETURN @ret;
END;

GO
GRANT EXECUTE ON [ConfirmMgr].[PKG_TRADE_RQMT$F_GET_INITIAL_STATUS] TO [stanford_developers] AS [cm_admin]
GO
