<#

.NAME
	CREATE_TRIGGERS
.SYNOPSIS
	SCRIPT DEVELOPED TO CREATE ALL DATABASE TRIGGERS OBJECTS 

.DESCRIPTION
	This script creates a DB TRIGGERS objects
	
.PARAMETERS 
	$dbusername   :  DatabaseUser with credentials to logon as sysadmin
	$dbuspassw    :  Password of Database User
	$srvinstance  :  SQL Server Instance to work
	$db_name      :  SQL Server Database Name to Script
	
	
.INPUTS
	
.OUTPUTS
	SchemaName.ObjectName.sql
	Error Log Results error.log
	
.EXAMPLE
 Ps c:\> .\CREATE_TRIGGERS.ps1

.NOTES
	Author        :	Javier Montero  - 11/25/2015
    Version       :	1.0	
	Compatibility :	PS 2.0 or Higher
	SQL Ver       :	SQL Server 2008R2 or Higher
	TO GET HELP OR ANY NOTE HERE TYPE GET-HELP .\CREATE_TRIGGERS.ps1
	
#>
param(
	
	[Parameter(Position=0, Mandatory=$true)]
	[string]$srvinstance,
	[Parameter(Position=1, Mandatory=$true)]
	[string]$dbuser,
	[Parameter(Position=2, Mandatory=$true)]
	[string]$dbuspassw,
	[Parameter(Position=3, Mandatory=$true)]
	[string]$dbname

)

$server              = $srvinstance
$user                = $dbuser
$passw               = $dbuspassw
$db_name             = $dbname
$scriptspath         = Split-Path -Parent $MyInvocation.MyCommand.Definition
$sqlerror            = $null
$script:errorcount     

# trap errors
$errors = $scriptspath+"\errors.log"


[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null #<-- Powershell V 2.0 Higher

$srv 		= New-Object "Microsoft.SqlServer.Management.SMO.Server" $server

#Login credentials
$srv.ConnectionContext.LoginSecure = $false;
#$credential = Get-Credential
$SqlUPwd = ConvertTo-SecureString $passw -AsPlainText -Force; #Converting Password text to Secury credentials
$srv.ConnectionContext.set_Login($user);
$srv.ConnectionContext.set_SecurePassword($SqlUPwd);

Write-Host $scriptspath
$pathfile = $scriptspath

function CREATING_OBJECTS($serverobj, $dbobj, $userobj, $passobj, $fileobj, $objname)
{
	        
			Write-Host "CREATING TRIGGERS " + $objname	
			Import-module SQLPS -DisableNameChecking
			Invoke-Sqlcmd -InputFile $fileobj `
			-ServerInstance $serverobj `
			-Database $dbobj `
			-Username $userobj `
			-Password $passobj `
			-ErrorAction SilentlyContinue `
	        -ErrorVariable sqlerror `
			| Out-File -filepath $scriptspath\"Triggers\logs\"$objname".log"	
			
	if($sqlerror -ne $null)
	{
		"__________________________________" | Out-File $errors -Append;
		"ERROR SCRIPTING " | Out-File $errors -Append;
		"Error on Script     : "+$objname | Out-File $errors -Append;
		"Exception Message   : "+$error[0].Exception.Message | Out-File $errors -Append;
		"Target Object       : "+$error[0].TargetObject | Out-File $errors -Append
		"Category Info       : "+$error[0].CategoryInfo | Out-File $errors -Append
		$sqlerror = $null;
		$script:errorcount++
		#Write-Host $script:errorcount.ToString()
	}

		    
		
	
}


if($pathfile -ne $null)
{
	$pathlist = Get-Item -Path $pathfile
	$fspath = $pathfile+"\Triggers"

		if(Test-Path $fspath -PathType Container)
		{
			
			if(Test-Path -Path $scriptspath\"Triggers\logs" -PathType Container)
			{
				Write-Host "Removing Previous Log Files If Exists"	
				Remove-Item $scriptspath\"Triggers\logs" -Include .log
				Set-Location $fspath
				Write-Host "If you need help about the parameters, Please Use the cmdlet Get-Help .\FileStreamAccess_Validation.ps1"
				$list = Get-ChildItem $fspath | Where-Object{$_.Extension -eq ".sql"}
				Write-Host "CREATING TRIGGERS ON CONFIRMATIONS MANAGER DATABASE...."
				Foreach($script in $list)
				{
					if($script -ne $null)
					{
						$text = Get-Content $script
						[string]$value = "$($fspath)\$script"		
						#Write-Host $value
						CREATING_OBJECTS $server $db_name $user $passw $value $script
						#Set-Location -Path .. -PassThru
					
					}	
					else
					{
						Write-Host ".SQL Script Don't exists please validate"
					}
				}
			}
			else
			{
				Write-Host "Creating Logs Folder"	
				New-Item $scriptspath\"Triggers\logs" -ItemType directory
				Set-Location $fspath
				Write-Host "If you need help about the parameters, Please Use the cmdlet Get-Help .\FileStreamAccess_Validation.ps1"
				$list = Get-ChildItem $fspath | Where-Object{$_.Extension -eq ".sql"}
				Write-Host "CREATING TRIGGERS ON CONFIRMATIONS MANAGER DATABASE...."
				Foreach($script in $list)
				{
					if($script -ne $null)
					{
						$text = Get-Content $script
						[string]$value = "$($fspath)\$script"		
						#Write-Host $value
						CREATING_OBJECTS $server $db_name $user $passw $value $script
						#Set-Location -Path .. -PassThru
					
					}	
					else
					{
						Write-Host ".SQL Script Don't exists please validate"
					}
				}
			}
		
			
			Set-Location -Path .. -PassThru
		}
		
	else
	{
		Write-Host "Failed"
	}
	
	if($script:errorcount -gt 0)
	{
		Write-Host "!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!"
		Write-Host "Errors Found During TRIGGERS Creation Process, Please Validate Error Log"
		Write-Host "Errors Count: " $script:errorcount.ToString()
		Write-Host "Error Log Path: " $errors.ToString()
		#Write-Host $script:errorcount.ToString()
	}
	else
	{
		Write-Host "No Errors Found During TRIGGERS Creation Process."
	}
	
}