/*CREATING LOGIN ID*/
CREATE USER cm_admin FOR LOGIN cm_admin WITH DEFAULT_SCHEMA = [ConfirmMgr]
GO
/*ADDING USER TO ROLES*/


ALTER AUTHORIZATION ON SCHEMA::[ConfirmMgr] TO [cm_admin]
GO

IF NOT EXISTS(SELECT 1 FROM master.sys.sql_logins where name = 'cnfmgrsvc')
CREATE LOGIN [cnfmgrsvc] WITH PASSWORD=N'cnfmgrsvc', 
DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO
/*CREATING USER IN cnf_mgr DB*/
CREATE USER cnfmgrsvc FOR LOGIN cnfmgrsvc WITH DEFAULT_SCHEMA = [ConfirmMgr]
GO
/*ADDING USER TO ROLES*/

IF NOT EXISTS(SELECT 1 FROM master.sys.sql_logins where name = 'rnell')
CREATE LOGIN [rnell] WITH PASSWORD=N'Ora11', DEFAULT_DATABASE=[master], DEFAULT_LANGUAGE=[us_english], CHECK_EXPIRATION=OFF, CHECK_POLICY=OFF
GO

CREATE USER rnell FOR LOGIN rnell WITH DEFAULT_SCHEMA = [ConfirmMgr]
GO
/*ADDING USER TO ROLES*/


/*KBARKMAN USER CREATION*/
PRINT'CREATING KBARKMAN USER!!!!!'
GO

IF NOT EXISTS(SELECT 1 FROM master.sys.sql_logins where name = 'kbarkman')
BEGIN
declare 
@loginuser varchar(200)
set @loginuser = 'kbarkman';
CREATE LOGIN [kbarkman] WITH PASSWORD = 'Oracle11', DEFAULT_DATABASE = cnf_mgr, CHECK_POLICY = OFF
END
go
CREATE USER kbarkman FOR LOGIN [kbarkman]
GO
ALTER USER [kbarkman] WITH DEFAULT_SCHEMA=[ConfirmMgr]
GO



IF NOT EXISTS(SELECT 1 FROM master.sys.sql_logins where name = 'icts\kbarkman')
BEGIN
CREATE LOGIN [icts\kbarkman] FROM WINDOWS WITH DEFAULT_DATABASE = cnf_mgr
END
go

USE cnf_mgr
go
CREATE USER [icts\kbarkman] FOR LOGIN [icts\kbarkman]
GO
ALTER USER [icts\kbarkman] WITH DEFAULT_SCHEMA=[ConfirmMgr]
GO
PRINT'KBARKMAN USER CREATED SUCCESSFULLY!!!!!'
GO


IF NOT EXISTS(SELECT 1 FROM master.sys.sql_logins where name = 'icts\dprasad')
BEGIN
CREATE LOGIN [icts\dprasad] FROM WINDOWS WITH DEFAULT_DATABASE = cnf_mgr
END
go
CREATE USER [icts\dprasad] FOR LOGIN [icts\dprasad]
GO
ALTER USER [icts\dprasad] WITH DEFAULT_SCHEMA=[ConfirmMgr]
GO
PRINT'DPRASAD USER CREATED SUCCESSFULLY!!!!!'
GO