SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [ConfirmMgr].[TRADE_DATA_JN](
	[JN_ORACLE_USER] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[JN_DATETIME] [datetime2](0) NOT NULL,
	[JN_OPERATION] [varchar](3) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[JN_HOST_NAME] [varchar](60) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[ID] [int] NOT NULL,
	[TRADE_ID] [int] NOT NULL,
	[INCEPTION_DT] [date] NULL,
	[CDTY_CODE] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TRADE_DT] [date] NULL,
	[XREF] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CPTY_SN] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[QTY_TOT] [numeric](24, 12) NULL,
	[LOCATION_SN] [varchar](50) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PRICE_DESC] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[START_DT] [date] NULL,
	[END_DT] [date] NULL,
	[BOOK] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TRADE_TYPE_CODE] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[STTL_TYPE] [varchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BROKER_SN] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BUY_SELL_IND] [varchar](5) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[REF_SN] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TRADE_STAT_CODE] [varchar](10) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CDTY_GRP_CODE] [varchar](15) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BROKER_PRICE] [varchar](60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OPTN_STRIKE_PRICE] [varchar](60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OPTN_PREM_PRICE] [varchar](60) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[OPTN_PUT_CALL_IND] [varchar](1) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PERMISSION_KEY] [varchar](20) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[PROFIT_CENTER] [varchar](64) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[CPTY_LEGAL_NAME] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[QTY_DESC] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TRADE_DESC] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BOOKING_CO_SN] [varchar](30) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BOOKING_CO_ID] [int] NULL,
	[CPTY_ID] [int] NULL,
	[BROKER_LEGAL_NAME] [varchar](255) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[BROKER_ID] [int] NULL,
	[TRANSPORT_DESC] [varchar](200) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[TRADER] [varchar](100) COLLATE SQL_Latin1_General_CP1_CI_AS NULL
) ON [PRIMARY]

GO
