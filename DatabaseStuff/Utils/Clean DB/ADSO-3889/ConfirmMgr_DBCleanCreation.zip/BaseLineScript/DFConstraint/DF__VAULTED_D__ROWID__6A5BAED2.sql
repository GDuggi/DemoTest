ALTER TABLE [ConfirmMgr].[VAULTED_DOCS_BLOB] ADD  DEFAULT (newsequentialid()) FOR [ROWID]
GO
