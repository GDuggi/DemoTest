ALTER TABLE [ConfirmMgr].[FAX_LOG_SENT] ADD  DEFAULT (sysdatetime()) FOR [CRTD_TS_GMT]
GO
