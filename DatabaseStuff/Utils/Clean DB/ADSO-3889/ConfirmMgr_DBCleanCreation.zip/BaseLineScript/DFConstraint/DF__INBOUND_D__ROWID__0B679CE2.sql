ALTER TABLE [ConfirmMgr].[INBOUND_DOCS_BLOB] ADD  DEFAULT (newsequentialid()) FOR [ROWID]
GO
