ALTER TABLE [ConfirmMgr].[TRADE_APPR] ADD  DEFAULT (upper(suser_name())) FOR [APPR_BY_USERNAME]
GO
