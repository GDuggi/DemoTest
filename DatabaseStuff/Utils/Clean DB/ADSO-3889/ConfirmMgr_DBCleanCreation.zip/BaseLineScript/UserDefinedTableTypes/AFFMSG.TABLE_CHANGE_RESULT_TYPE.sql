CREATE TYPE [AFFMSG].[TABLE_CHANGE_RESULT_TYPE] AS TABLE(
	[message_type_name] [sysname] COLLATE SQL_Latin1_General_CP1_CI_AS NOT NULL,
	[message_body] [varchar](4000) COLLATE SQL_Latin1_General_CP1_CI_AS NULL,
	[message_sequence_number] [bigint] NULL,
	[conversation_handle] [uniqueidentifier] NULL
)
GO
