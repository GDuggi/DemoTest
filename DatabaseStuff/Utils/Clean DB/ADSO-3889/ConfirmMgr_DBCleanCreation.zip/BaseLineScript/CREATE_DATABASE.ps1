﻿<############################################################################################################################
#
Company:		Amphora Inc.
Author:			Javier Montero - 11/11/2015
Version:		1.0
Compatibility:	PowerShell 3.0 or Higher
SQL Server Ver:	SQL Server 2012 or Higher
Modified:	
Description:	This software script was develop to build a Confirmations Manager Database baseline
				this software script is the principal script to invoke the SQL Server scripts to Setup the Database 
Copyright:		All rights Reserved. 
				This software was develop and distribuited exclusive to use in the Amphora Inc. Systems and Databases
				is prohibe used this code by 3er party without Amphora Inc. Authorization, 
				Amphora Inc. is not responsable for damage or loss information for unauthorized use of this software. 
#
###############################################################################################################################>


param(
	[String] $pathfolder, #variable used to get the actual location of the folder from where is execute the PS1 file. 
	[Parameter(Position=0, Mandatory=$true)]
	[string] $svrinstance,
	[Parameter(Position=1, Mandatory=$true)]
	[string] $dbuser,
	[Parameter(Position=2, Mandatory=$true)]
	[string] $dbusupassw,
	[Parameter(Position=3, Mandatory=$true)]
	[string] $dbname
)

#Variable Initialization
$sqlinstance    = $svrinstance
$userdb         = $dbuser
$passdb         = $dbusupassw  
$namedb         = $dbname

# trap errors variable and path
$errors = $scriptspath+"\errors.log"


#Main Program
try
{
	
	Write-Output "Baseline Script to Set Up Confirmation Manager Database"
	$pathfolder = Split-Path -Parent $MyInvocation.MyCommand.Definition
	
	if($pathfolder -ne $null)
	{
		Write-Host $pathfolder
		$psfile = $PSScriptRoot + ".\FileStreamAccess_Validation.ps1"
		.$psfile $sqlinstance $userdb $passdb
		$psfile = $PSScriptRoot + ".\CreateDataBase.ps1"
		.$psfile $sqlinstance $userdb $passdb
		$psfile = $PSScriptRoot + ".\CREATE_SCHEMA.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_TABLES.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_USERS.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_ROLES.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_SEQUENCES.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_UDF.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_UDTT.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_VIEWS.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_SPROCEDURES.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_DFCONSTRAINT.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_CHKCONSTRAINT.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_PRIMARYKEYS.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_TRIGGERS.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_SBQUEUES_SERVICES.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
		$psfile = $PSScriptRoot + ".\CREATE_FKEYS.ps1"
		.$psfile $sqlinstance $userdb $passdb $namedb
	}
	
	
}
catch
{
  "______________________" | out-file $errors -append;
  "ERROR SCRIPTING " | out-file $errors -append;
  get-date | out-file $errors -append;
  "ERROR: " + $_ | out-file $errors -append;
  "`$server = $server" | out-file $errors -append;
  "`$database = $db_name" | out-file $errors -append;
}